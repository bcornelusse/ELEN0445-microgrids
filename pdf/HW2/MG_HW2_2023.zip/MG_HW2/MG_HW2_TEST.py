# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
# KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
# PARTICULAR PURPOSE.


# If HIL device is present, model will be compiled for detected HIL.
# Otherwise model will be compiled for VHIL402 C1.

import typhoon.api.hil as hil
from typhoon.api.schematic_editor import model as mdl
import typhoon.test.capture as capture
import typhoon.test.signals as sig
from pathlib import Path
import pytest
import logging
import os

logger = logging.getLogger(__name__)

# script directory
FILE_DIR_PATH = Path(__file__).parent

model_path = str(FILE_DIR_PATH / "MG_HW2.tse")
compiled_model_path = mdl.get_compiled_model_file(model_path)
pv_curve_path = str(FILE_DIR_PATH / "solar panel.ipvx")

# T° and I operating points, by default each will be simulated for "Wait_Time" seconds
irradiance = [1400, 1000, 800, 500]
temp = [20, 22, 30, 25]

V_incr = 1 					# Can also be a list and zipped to test multiple values
Wait_Time = 2 					# seconds to converge for each point of the profile


control = [0,1,2,3]
name = ['idle', 'frac', 'P&O', 'GI']
parameter = zip(control, name) 		# Formatting to be used to conduct multiple tests (1 for each controller)
# This profile is quite unrealistic, but shows how quick convergence is for your algorithms
# Feel free to test with this + to change data

@pytest.fixture(scope="module")
def setup_fcn():
    
    # Loading of the model
    mdl.load(model_path)

    # Detecting of hardware settings
    try:
        hw_settings = mdl.detect_hw_settings()
        vhil_device = False
        logger.info("{} {} device is used".format(hw_settings[0], hw_settings[2]))
    except Exception:
        vhil_device = True
        logger.info("VHIL402 C1 device is used")
        
    # Comilation of the model uncomment this if you haven't compiled in the schematic_editor
    # mdl.compile()

    # Loading of the model in HIL 
    hil.load_model(compiled_model_path, vhil_device=vhil_device)

    # Set the source/scada input values -> to be completed if you add some in SCADA
    hil.set_source_sine_waveform('Vs1', rms=230, frequency=50.0, phase=0.0, harmonics_pu=())


    hil.set_pv_input_file('Photovoltaic Panel 1', file=os.path.join(FILE_DIR_PATH,
                          "solar panel.ipvx"),
                          illumination=1000,
                          temperature=20)
    # You should maybe add something here for one of the controllers
    
@pytest.mark.parametrize('ctrl, name', parameter)
def test_multiple(setup_fcn, ctrl, name):
    # Starting of the capture
    cap_signals = ["Single Phase Inverter.Vdc_MPPT.Vdc_ref"]     #  You should add other signals
    capture.start_capture(duration=Wait_Time*len(irradiance), rate=10000, signals=cap_signals, executeAt=0.5)
    # executeAt is necessary not to not show first half second of simulation
    # where transients occur. If you still see some transients from connecting the
    # PV you should increase this param and the 'wait_sec' just bellow as much
    
    
    # Start the simulation
    hil.start_simulation()
    
    #Set the different parameters
    hil.set_scada_input_value('Single Phase Inverter.Vdc_MPPT.MPPT.V_incr', V_incr)
    hil.set_scada_input_value('Single Phase Inverter.Vdc_MPPT.MPPT.MPPT_mode', ctrl)
    
    # Activate PV panel
    hil.set_scada_input_value('PV_in.Connect', 1.0)
    hil.set_scada_input_value('PV_in.Enable', 1.0)
    hil.wait_sec(0.5)       # Wait half a second to remove transients from connecting the PV
    
    for i in range(len(irradiance)):
        # Setting the SCADA inputs 
        
        # Setting PV input file
        hil.set_pv_amb_params('Photovoltaic Panel 1',
                              illumination=irradiance[i],
                              temperature=temp[i])
                              
        # You should maybe add something here for one of the controller
        
        hil.wait_sec(Wait_Time)
    # Get capture results
    capt = capture.get_capture_results()
        
    # Stop the simulation
    hil.stop_simulation()