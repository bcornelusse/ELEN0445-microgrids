// generated using template: cop_main.template---------------------------------------------
/******************************************************************************************
**
**  Module Name: cop_main.c
**  NOTE: Automatically generated file. DO NOT MODIFY!
**  Description:
**            Main file
**
******************************************************************************************/
// generated using template: arm/custom_include.template-----------------------------------

#ifdef __cplusplus
#include <limits>

extern "C" {
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <complex.h>

// x86 libraries:
#include "../include/sp_functions_dev0.h"

#ifdef __cplusplus
}
#endif

// H files from Advanced C Function components


// Header files from additional sources (Advanced C Function)

// ----------------------------------------------------------------------------------------                // generated using template:generic_macros.template-----------------------------------------
/*********************** Macros (Inline Functions) Definitions ***************************/

// ----------------------------------------------------------------------------------------

#ifndef MAX
#define MAX(value, limit) (((value) > (limit)) ? (value) : (limit))
#endif
#ifndef MIN
#define MIN(value, limit) (((value) < (limit)) ? (value) : (limit))
#endif

// generated using template: VirtualHIL/custom_defines.template----------------------------

typedef unsigned char X_UnInt8;
typedef char X_Int8;
typedef signed short X_Int16;
typedef unsigned short X_UnInt16;
typedef int X_Int32;
typedef unsigned int X_UnInt32;
typedef unsigned int uint;
typedef double real;

// ----------------------------------------------------------------------------------------
// generated using template: custom_consts.template----------------------------------------

// arithmetic constants
#define C_SQRT_2                    1.4142135623730950488016887242097f
#define C_SQRT_3                    1.7320508075688772935274463415059f
#define C_PI                        3.1415926535897932384626433832795f
#define C_E                         2.7182818284590452353602874713527f
#define C_2PI                       6.283185307179586476925286766559f

//@cmp.def.start
//component defines






























































































































































































//@cmp.def.end


//-----------------------------------------------------------------------------------------
// generated using template: common_variables.template-------------------------------------
// true global variables


//@cmp.var.start
// variables
double _pv_in_connect__out;
double _pv_in_enable__out;
double _pv_in_q_mode__out;
double _pv_in_q_ref__out;
double _single_phase_inverter_constant1__out = 0.0;
double _single_phase_inverter_current_controller_constant3__out = 1.0;
double _single_phase_inverter_current_controller_limit_pqref_unit_delay1__out;
double _single_phase_inverter_current_controller_limit_pqref_unit_delay2__out;
double _single_phase_inverter_current_controller_power_meas_gain4__out;
double _single_phase_inverter_current_controller_power_meas_gain5__out;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__P;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__Q;


double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__S;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__pf;
X_Int32 _single_phase_inverter_current_controller_single_phase_pll1_constant2__out = 2;
double _single_phase_inverter_current_controller_single_phase_pll1_i__out;
double _single_phase_inverter_current_controller_single_phase_pll1_i__pi_reg_out_int;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator1__out;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator10__out;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator2__out;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator3__out;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator4__out;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator5__out;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator6__out;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator7__out;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator8__out;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator9__out;
double _single_phase_inverter_current_controller_single_phase_pll1_trigonometric_function1__out;
double _single_phase_inverter_current_controller_single_phase_pll1_const__out = 345.57519189487726;
double _single_phase_inverter_iout_ia1__out;
double _single_phase_inverter_vdc_va1__out;
double _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation1_constant1__out = 2.0;
double _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation2_constant1__out = 2.0;
double _single_phase_inverter_vdc_mppt_mppt_mppt_mode__out;
double _single_phase_inverter_vdc_mppt_mppt_v_incr__out;
double _single_phase_inverter_vout_va1__out;
double _pv_in_bus_join1__out[4];
double _single_phase_inverter_current_controller_gain7__out;
double _single_phase_inverter_current_controller_power_meas_gain6__out;
double _single_phase_inverter_current_controller_single_phase_pll1_c_function1__theta_dq;
double _single_phase_inverter_current_controller_single_phase_pll1_c_function1__va;
double _single_phase_inverter_current_controller_single_phase_pll1_c_function1__vb;


double _single_phase_inverter_current_controller_single_phase_pll1_c_function1__vd;
double _single_phase_inverter_current_controller_single_phase_pll1_c_function1__vq;
double _single_phase_inverter_current_controller_current_ref1_limit5__out;
double _single_phase_inverter_current_controller_single_phase_pll1_sum4__out;
double _single_phase_inverter_current_controller_single_phase_pll1_product2__out;
double _single_phase_inverter_current_controller_single_phase_pll1_w_to_f__out;
double _single_phase_inverter_current_controller_single_phase_pll1_sum9__out;
double _single_phase_inverter_current_controller_single_phase_pll1_sum11__out;
double _single_phase_inverter_current_controller_single_phase_pll1_sum13__out;
double _single_phase_inverter_current_controller_single_phase_pll1_sum14__out;
double _single_phase_inverter_current_controller_gain6__out;
double _single_phase_inverter_rms_value2__out;
X_UnInt32 _single_phase_inverter_rms_value2__zc;
double _single_phase_inverter_limit5__out;
double _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation2_power_of_2__out;
double _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation1_power_of_2__out;

double _single_phase_inverter_vdc_mppt_mppt_mppt__V_k;
X_UnInt32 _single_phase_inverter_vdc_mppt_mppt_mppt__enable;
double _single_phase_inverter_vdc_mppt_mppt_mppt__incr;


double _single_phase_inverter_vdc_mppt_mppt_mppt__V_ref;
double _single_phase_inverter_current_controller_gain1__out;
double _single_phase_inverter_current_controller_gain3__out;
double _single_phase_inverter_rms_value1__out;
X_UnInt32 _single_phase_inverter_rms_value1__zc;
double _single_phase_inverter_input_bus_split2__out;
double _single_phase_inverter_input_bus_split2__out1;
double _single_phase_inverter_input_bus_split2__out2;
double _single_phase_inverter_input_bus_split2__out3;
double _single_phase_inverter_current_controller_current_ref1_limit4__out;
double _single_phase_inverter_current_controller_single_phase_pll1_gain3__out;
double _single_phase_inverter_current_controller_single_phase_pll1_math_f1__out;
double _single_phase_inverter_current_controller_single_phase_pll1_math_f2__out;
double _single_phase_inverter_current_controller_current_ref1_product4__out;
double _single_phase_inverter_current_controller_current_ref1_product5__out;
double _single_phase_inverter_current_controller_current_ref1_squared_vt_product1__out;
double _single_phase_inverter_current_controller_single_phase_pll1_gain5__out;
double _single_phase_inverter_current_controller_single_phase_pll1_sum12__out;
double _single_phase_inverter_current_controller_single_phase_pll1_gain7__out;
double _single_phase_inverter_current_controller_single_phase_pll1_gain8__out;
double _single_phase_inverter_current_controller_single_phase_pll1_gain10__out;
double _single_phase_inverter_current_controller_single_phase_pll1_gain11__out;
double _single_phase_inverter_current_controller_osg_discrete_transfer_function1__out;
double _single_phase_inverter_current_controller_osg_discrete_transfer_function1__b_coeff[2] = { -1.0, 1.0314159265358978};
double _single_phase_inverter_current_controller_osg_discrete_transfer_function1__a_coeff[2] = {1.0, -0.968584073464102};
double _single_phase_inverter_current_controller_osg_discrete_transfer_function1__a_sum;
double _single_phase_inverter_current_controller_osg_discrete_transfer_function1__b_sum;
double _single_phase_inverter_current_controller_osg_discrete_transfer_function1__delay_line_in;
double _single_phase_inverter_current_controller_dq_current_controller_limit3__out;
double _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation2_gain2__out;
double _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation1_gain2__out;
double _single_phase_inverter_current_controller_gain8__out;
float _single_phase_inverter_q_mode__tmp;
double _single_phase_inverter_signal_switch1__out;

double _single_phase_inverter_delay1__in;


double _single_phase_inverter_delay1__out;
double _single_phase_inverter_current_controller_current_ref1_product3__out;
double _single_phase_inverter_current_controller_current_ref1_product6__out;
double _single_phase_inverter_current_controller_current_ref1_squared_vt_product2__out;
double _single_phase_inverter_current_controller_single_phase_pll1_sum7__out;
double _single_phase_inverter_current_controller_single_phase_pll1_sum6__out;
double _single_phase_inverter_current_controller_single_phase_pll1_gain9__out;
double _single_phase_inverter_current_controller_alpha_beta_to_dq2__d;
double _single_phase_inverter_current_controller_alpha_beta_to_dq2__q;
double _single_phase_inverter_current_controller_alpha_beta_to_dq2__k1;
double _single_phase_inverter_current_controller_alpha_beta_to_dq2__k2;
double _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation2_gain3__out;
double _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation1_gain3__out;
double _single_phase_inverter_current_controller_single_phase_pll1_sum1__out;
double _single_phase_inverter_current_controller_gain2__out;
double _single_phase_inverter_logical_operator2__out;
double _single_phase_inverter_current_controller_current_ref1_sum3__out;
double _single_phase_inverter_current_controller_current_ref1_sum4__out;
double _single_phase_inverter_current_controller_current_ref1_squared_vt_sum3__out;
double _single_phase_inverter_current_controller_single_phase_pll1_gain4__out;
double _single_phase_inverter_current_controller_single_phase_pll1_math1__out;
double _single_phase_inverter_current_controller_dq_current_controller_gain4__out;
double _single_phase_inverter_current_controller_dq_current_controller_gain7__out;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_product1__out;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_product2__out;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_product3__out;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_product4__out;
double _single_phase_inverter_vdc_mppt_dc_voltage_controller_sum1__out;
double _single_phase_inverter_current_controller_single_phase_pll1_gain2__out;
double _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref;
double _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref;
double _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax;


double _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__P;
double _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q;
double _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__S;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d_integrator1__out;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d2_integrator1__out;
float _single_phase_inverter_on_inv__tmp;
double _single_phase_inverter_output_bus_join1__out[9];
double _single_phase_inverter_current_controller_current_ref1_limit3__out;
double _single_phase_inverter_current_controller_single_phase_pll1_limit1__out;
double _single_phase_inverter_current_controller_dq_current_controller_product1__out;
double _single_phase_inverter_current_controller_dq_current_controller_product6__out;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_sum1__out;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_sum2__out;

double _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__enable;
double _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__error;


double _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__out;
double _single_phase_inverter_current_controller_single_phase_pll1_sum2__out;
double _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__out;
double _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__out;
double _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__out;
double _single_phase_inverter_current_controller_current_ref1_product1__out;
double _single_phase_inverter_current_controller_current_ref1_product2__out;
double _single_phase_inverter_current_controller_single_phase_pll1_product8__out;
double _single_phase_inverter_current_controller_dq_current_controller_sum10__out;
double _single_phase_inverter_current_controller_dq_current_controller_sum13__out;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__out;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__b_coeff[2] = {0.0003140606003114721, 0.0003140606003114721};
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__a_coeff[2] = {1.0, -0.999371878799377};
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__a_sum;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__b_sum;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__delay_line_in;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__out;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__b_coeff[2] = {0.0003140606003114721, 0.0003140606003114721};
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__a_coeff[2] = {1.0, -0.999371878799377};
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__a_sum;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__b_sum;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__delay_line_in;
double _single_phase_inverter_current_controller_single_phase_pll1_product1__out;

double _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Pref;
double _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Qref;
double _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Sref;


double _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__P;
double _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Q;
double _single_phase_inverter_current_controller_dq_current_controller_sum2__out;
double _single_phase_inverter_current_controller_dq_current_controller_sum1__out;
double _single_phase_inverter_current_controller_single_phase_pll1_abs1__out;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d2_gain1__out;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d2_gain2__out;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d_gain1__out;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d_gain2__out;
double _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_table[100] = { -5.19, -5.142818181818182, -5.095636363636364, -5.048454545454546, -5.0012727272727275, -4.954090909090909, -4.9069090909090916, -4.859727272727273, -4.812545454545455, -4.765363636363636, -4.718181818181819, -4.671, -4.623818181818182, -4.576636363636364, -4.529454545454546, -4.482272727272727, -4.43509090909091, -4.387909090909091, -4.340727272727273, -4.2935454545454546, -4.246363636363637, -4.199181818181819, -4.152, -4.104818181818182, -4.057636363636364, -4.010454545454546, -3.9632727272727273, -3.9160909090909093, -3.8689090909090913, -3.821727272727273, -3.774545454545455, -3.727363636363637, -3.6801818181818184, -3.633, -3.585818181818182, -3.538636363636364, -3.4914545454545456, -3.4442727272727276, -3.3970909090909096, -3.349909090909091, -3.3027272727272727, -3.2555454545454547, -3.2083636363636368, -3.1611818181818183, -3.1140000000000003, -3.066818181818182, -3.019636363636364, -2.9724545454545455, -2.9252727272727275, -2.8780909090909095, -2.830909090909091, -2.783727272727273, -2.7365454545454546, -2.6893636363636366, -2.642181818181818, -2.595, -2.547818181818182, -2.5006363636363638, -2.4534545454545458, -2.4062727272727273, -2.3590909090909093, -2.311909090909091, -2.264727272727273, -2.2175454545454545, -2.1703636363636365, -2.1231818181818185, -2.076, -2.028818181818182, -1.9816363636363636, -1.9344545454545456, -1.8872727272727272, -1.8400909090909092, -1.7929090909090908, -1.7457272727272728, -1.6985454545454548, -1.6513636363636364, -1.6041818181818184, -1.557, -1.509818181818182, -1.4626363636363635, -1.4154545454545455, -1.3682727272727275, -1.321090909090909, -1.273909090909091, -1.2267272727272727, -1.1795454545454547, -1.1323636363636362, -1.0851818181818178, -1.0380000000000003, -0.9908181818181818, -0.9436363636363634, -0.8964545454545458, -0.8492727272727274, -0.802090909090909, -0.7549090909090905, -0.707727272727273, -0.6605454545454545, -0.6133636363636361, -0.5661818181818186, -0.519 };
double _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__value;
double _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_addrs[100] = { 0.0, 0.010101010101010102, 0.020202020202020204, 0.030303030303030304, 0.04040404040404041, 0.05050505050505051, 0.06060606060606061, 0.07070707070707072, 0.08080808080808081, 0.09090909090909091, 0.10101010101010102, 0.11111111111111112, 0.12121212121212122, 0.13131313131313133, 0.14141414141414144, 0.15151515151515152, 0.16161616161616163, 0.17171717171717174, 0.18181818181818182, 0.19191919191919193, 0.20202020202020204, 0.21212121212121213, 0.22222222222222224, 0.23232323232323235, 0.24242424242424243, 0.25252525252525254, 0.26262626262626265, 0.27272727272727276, 0.2828282828282829, 0.29292929292929293, 0.30303030303030304, 0.31313131313131315, 0.32323232323232326, 0.33333333333333337, 0.3434343434343435, 0.3535353535353536, 0.36363636363636365, 0.37373737373737376, 0.38383838383838387, 0.393939393939394, 0.4040404040404041, 0.4141414141414142, 0.42424242424242425, 0.43434343434343436, 0.4444444444444445, 0.4545454545454546, 0.4646464646464647, 0.4747474747474748, 0.48484848484848486, 0.494949494949495, 0.5050505050505051, 0.5151515151515152, 0.5252525252525253, 0.5353535353535354, 0.5454545454545455, 0.5555555555555556, 0.5656565656565657, 0.5757575757575758, 0.5858585858585859, 0.595959595959596, 0.6060606060606061, 0.6161616161616162, 0.6262626262626263, 0.6363636363636365, 0.6464646464646465, 0.6565656565656566, 0.6666666666666667, 0.6767676767676768, 0.686868686868687, 0.696969696969697, 0.7070707070707072, 0.7171717171717172, 0.7272727272727273, 0.7373737373737375, 0.7474747474747475, 0.7575757575757577, 0.7676767676767677, 0.7777777777777778, 0.787878787878788, 0.797979797979798, 0.8080808080808082, 0.8181818181818182, 0.8282828282828284, 0.8383838383838385, 0.8484848484848485, 0.8585858585858587, 0.8686868686868687, 0.8787878787878789, 0.888888888888889, 0.8989898989898991, 0.9090909090909092, 0.9191919191919192, 0.9292929292929294, 0.9393939393939394, 0.9494949494949496, 0.9595959595959597, 0.9696969696969697, 0.9797979797979799, 0.98989898989899, 1.0 };
X_Int32 _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__leftIndex;
X_Int32 _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__rightIndex;
X_Int32 _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__curAddr;
double _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__fraction;

double _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_table[100] = { 18400.0, 18236.565656565657, 18073.131313131315, 17909.696969696968, 17746.262626262625, 17582.828282828283, 17419.39393939394, 17255.959595959597, 17092.52525252525, 16929.090909090908, 16765.656565656565, 16602.222222222223, 16438.78787878788, 16275.353535353535, 16111.91919191919, 15948.484848484848, 15785.050505050505, 15621.61616161616, 15458.181818181818, 15294.747474747473, 15131.31313131313, 14967.878787878788, 14804.444444444445, 14641.0101010101, 14477.575757575756, 14314.141414141413, 14150.70707070707, 13987.272727272728, 13823.838383838383, 13660.404040404039, 13496.969696969696, 13333.535353535353, 13170.10101010101, 13006.666666666666, 12843.232323232322, 12679.797979797979, 12516.363636363636, 12352.929292929293, 12189.494949494949, 12026.060606060606, 11862.626262626261, 11699.191919191919, 11535.757575757576, 11372.323232323231, 11208.888888888889, 11045.454545454544, 10882.020202020201, 10718.585858585859, 10555.151515151514, 10391.717171717171, 10228.282828282827, 10064.848484848484, 9901.414141414141, 9737.979797979797, 9574.545454545454, 9411.111111111111, 9247.676767676767, 9084.242424242424, 8920.80808080808, 8757.373737373737, 8593.939393939394, 8430.50505050505, 8267.070707070707, 8103.636363636362, 7940.202020202019, 7776.767676767677, 7613.333333333332, 7449.898989898989, 7286.464646464645, 7123.030303030302, 6959.595959595959, 6796.161616161615, 6632.727272727272, 6469.2929292929275, 6305.858585858585, 6142.424242424242, 5978.9898989898975, 5815.555555555555, 5652.121212121212, 5488.6868686868675, 5325.252525252525, 5161.81818181818, 4998.383838383837, 4834.949494949495, 4671.51515151515, 4508.080808080807, 4344.646464646463, 4181.21212121212, 4017.7777777777774, 3854.343434343433, 3690.90909090909, 3527.4747474747455, 3364.040404040403, 3200.60606060606, 3037.1717171717155, 2873.7373737373728, 2710.303030303028, 2546.8686868686855, 2383.4343434343427, 2220.0 };
double _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__value;
double _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_addrs[100] = { 0.0, 0.010101010101010102, 0.020202020202020204, 0.030303030303030304, 0.04040404040404041, 0.05050505050505051, 0.06060606060606061, 0.07070707070707072, 0.08080808080808081, 0.09090909090909091, 0.10101010101010102, 0.11111111111111112, 0.12121212121212122, 0.13131313131313133, 0.14141414141414144, 0.15151515151515152, 0.16161616161616163, 0.17171717171717174, 0.18181818181818182, 0.19191919191919193, 0.20202020202020204, 0.21212121212121213, 0.22222222222222224, 0.23232323232323235, 0.24242424242424243, 0.25252525252525254, 0.26262626262626265, 0.27272727272727276, 0.2828282828282829, 0.29292929292929293, 0.30303030303030304, 0.31313131313131315, 0.32323232323232326, 0.33333333333333337, 0.3434343434343435, 0.3535353535353536, 0.36363636363636365, 0.37373737373737376, 0.38383838383838387, 0.393939393939394, 0.4040404040404041, 0.4141414141414142, 0.42424242424242425, 0.43434343434343436, 0.4444444444444445, 0.4545454545454546, 0.4646464646464647, 0.4747474747474748, 0.48484848484848486, 0.494949494949495, 0.5050505050505051, 0.5151515151515152, 0.5252525252525253, 0.5353535353535354, 0.5454545454545455, 0.5555555555555556, 0.5656565656565657, 0.5757575757575758, 0.5858585858585859, 0.595959595959596, 0.6060606060606061, 0.6161616161616162, 0.6262626262626263, 0.6363636363636365, 0.6464646464646465, 0.6565656565656566, 0.6666666666666667, 0.6767676767676768, 0.686868686868687, 0.696969696969697, 0.7070707070707072, 0.7171717171717172, 0.7272727272727273, 0.7373737373737375, 0.7474747474747475, 0.7575757575757577, 0.7676767676767677, 0.7777777777777778, 0.787878787878788, 0.797979797979798, 0.8080808080808082, 0.8181818181818182, 0.8282828282828284, 0.8383838383838385, 0.8484848484848485, 0.8585858585858587, 0.8686868686868687, 0.8787878787878789, 0.888888888888889, 0.8989898989898991, 0.9090909090909092, 0.9191919191919192, 0.9292929292929294, 0.9393939393939394, 0.9494949494949496, 0.9595959595959597, 0.9696969696969697, 0.9797979797979799, 0.98989898989899, 1.0 };
X_Int32 _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__leftIndex;
X_Int32 _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__rightIndex;
X_Int32 _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__curAddr;
double _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__fraction;

double _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_table[100] = { 4810.0, 4766.737373737374, 4723.474747474747, 4680.212121212121, 4636.949494949495, 4593.686868686868, 4550.424242424242, 4507.161616161617, 4463.89898989899, 4420.636363636364, 4377.373737373738, 4334.111111111111, 4290.848484848485, 4247.585858585859, 4204.323232323232, 4161.060606060606, 4117.79797979798, 4074.5353535353534, 4031.272727272727, 3988.010101010101, 3944.747474747475, 3901.4848484848485, 3858.222222222222, 3814.959595959596, 3771.69696969697, 3728.4343434343436, 3685.1717171717173, 3641.909090909091, 3598.6464646464647, 3555.3838383838383, 3512.121212121212, 3468.8585858585857, 3425.5959595959594, 3382.333333333333, 3339.070707070707, 3295.808080808081, 3252.5454545454545, 3209.282828282828, 3166.0202020202023, 3122.757575757576, 3079.4949494949497, 3036.2323232323233, 2992.969696969697, 2949.7070707070707, 2906.4444444444443, 2863.181818181818, 2819.9191919191917, 2776.6565656565654, 2733.3939393939395, 2690.131313131313, 2646.868686868687, 2603.6060606060605, 2560.343434343434, 2517.080808080808, 2473.818181818182, 2430.5555555555557, 2387.2929292929293, 2344.030303030303, 2300.7676767676767, 2257.5050505050503, 2214.242424242424, 2170.979797979798, 2127.717171717172, 2084.4545454545455, 2041.1919191919192, 1997.9292929292928, 1954.6666666666665, 1911.4040404040402, 1868.1414141414143, 1824.878787878788, 1781.6161616161617, 1738.3535353535353, 1695.090909090909, 1651.8282828282827, 1608.5656565656564, 1565.3030303030305, 1522.0404040404042, 1478.7777777777778, 1435.5151515151515, 1392.2525252525252, 1348.9898989898988, 1305.7272727272725, 1262.4646464646466, 1219.2020202020203, 1175.939393939394, 1132.6767676767677, 1089.4141414141413, 1046.151515151515, 1002.8888888888887, 959.6262626262628, 916.3636363636365, 873.1010101010102, 829.8383838383838, 786.5757575757575, 743.3131313131312, 700.0505050505053, 656.787878787879, 613.5252525252527, 570.2626262626263, 527.0 };
double _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__value;
double _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_addrs[100] = { 0.0, 0.010101010101010102, 0.020202020202020204, 0.030303030303030304, 0.04040404040404041, 0.05050505050505051, 0.06060606060606061, 0.07070707070707072, 0.08080808080808081, 0.09090909090909091, 0.10101010101010102, 0.11111111111111112, 0.12121212121212122, 0.13131313131313133, 0.14141414141414144, 0.15151515151515152, 0.16161616161616163, 0.17171717171717174, 0.18181818181818182, 0.19191919191919193, 0.20202020202020204, 0.21212121212121213, 0.22222222222222224, 0.23232323232323235, 0.24242424242424243, 0.25252525252525254, 0.26262626262626265, 0.27272727272727276, 0.2828282828282829, 0.29292929292929293, 0.30303030303030304, 0.31313131313131315, 0.32323232323232326, 0.33333333333333337, 0.3434343434343435, 0.3535353535353536, 0.36363636363636365, 0.37373737373737376, 0.38383838383838387, 0.393939393939394, 0.4040404040404041, 0.4141414141414142, 0.42424242424242425, 0.43434343434343436, 0.4444444444444445, 0.4545454545454546, 0.4646464646464647, 0.4747474747474748, 0.48484848484848486, 0.494949494949495, 0.5050505050505051, 0.5151515151515152, 0.5252525252525253, 0.5353535353535354, 0.5454545454545455, 0.5555555555555556, 0.5656565656565657, 0.5757575757575758, 0.5858585858585859, 0.595959595959596, 0.6060606060606061, 0.6161616161616162, 0.6262626262626263, 0.6363636363636365, 0.6464646464646465, 0.6565656565656566, 0.6666666666666667, 0.6767676767676768, 0.686868686868687, 0.696969696969697, 0.7070707070707072, 0.7171717171717172, 0.7272727272727273, 0.7373737373737375, 0.7474747474747475, 0.7575757575757577, 0.7676767676767677, 0.7777777777777778, 0.787878787878788, 0.797979797979798, 0.8080808080808082, 0.8181818181818182, 0.8282828282828284, 0.8383838383838385, 0.8484848484848485, 0.8585858585858587, 0.8686868686868687, 0.8787878787878789, 0.888888888888889, 0.8989898989898991, 0.9090909090909092, 0.9191919191919192, 0.9292929292929294, 0.9393939393939394, 0.9494949494949496, 0.9595959595959597, 0.9696969696969697, 0.9797979797979799, 0.98989898989899, 1.0 };
X_Int32 _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__leftIndex;
X_Int32 _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__rightIndex;
X_Int32 _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__curAddr;
double _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__fraction;

double _single_phase_inverter_current_controller_dq_current_controller_pi_d2_sum5__out;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d_sum5__out;
double _single_phase_inverter_current_controller_single_phase_pll1_product6__out;
double _single_phase_inverter_current_controller_single_phase_pll1_product5__out;
double _single_phase_inverter_current_controller_single_phase_pll1_product7__out;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d2_limit1__out;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d_limit1__out;
double _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__out;
double _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__b_coeff[2] = {1.0, -1.0};
double _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__a_coeff[2] = {1.0, -0.5589046363043405};
double _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__a_sum;
double _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__b_sum;
double _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__delay_line_in;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d2_sum6__out;
double _single_phase_inverter_current_controller_dq_current_controller_sum12__out;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d_sum6__out;
double _single_phase_inverter_current_controller_dq_current_controller_sum9__out;
double _single_phase_inverter_current_controller_single_phase_pll1_sum8__out;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d2_kb__out;
double _single_phase_inverter_current_controller_dq_current_controller_product7__out;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d_kb__out;
double _single_phase_inverter_current_controller_dq_current_controller_product5__out;
double _single_phase_inverter_current_controller_single_phase_pll1_limit2__out;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d2_sum7__out;
double _single_phase_inverter_current_controller_limit4__out;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d_sum7__out;
double _single_phase_inverter_current_controller_limit3__out;
double _single_phase_inverter_current_controller_single_phase_pll1_sum5__out;
double _single_phase_inverter_current_controller_dq_to_alpha_beta1__alpha;
double _single_phase_inverter_current_controller_dq_to_alpha_beta1__beta;
double _single_phase_inverter_current_controller_dq_to_alpha_beta1__k1;
double _single_phase_inverter_current_controller_dq_to_alpha_beta1__k2;
double _single_phase_inverter_current_controller_single_phase_pll1_sum10__out;

double _single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__in;


double _single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__out;
double _single_phase_inverter_gain1__out;
double _single_phase_inverter_current_controller_single_phase_pll1_gain6__out;
X_UnInt32 _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[2] = {0, 1};
double _single_phase_inverter_single_phase_inverter_pwm_modulator__limited_in[2];
X_UnInt32 _single_phase_inverter_single_phase_inverter_pwm_modulator__update_mask;
X_UnInt32 _single_phase_inverter_single_phase_inverter_pwm_modulator__sig_dir[2];

//@cmp.var.end

//@cmp.svar.start
// state variables
double _single_phase_inverter_current_controller_limit_pqref_unit_delay1__state;
double _single_phase_inverter_current_controller_limit_pqref_unit_delay2__state;
double _single_phase_inverter_current_controller_single_phase_pll1_i__integrator_state;
X_Int32 _single_phase_inverter_current_controller_single_phase_pll1_i__av_active;
double _single_phase_inverter_current_controller_single_phase_pll1_i__filter_state;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator1__state;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator10__state;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator2__state;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator3__state;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator4__state;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator5__state;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator6__state;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator7__state;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator8__state;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator9__state;
double _single_phase_inverter_rate_transition2_output__out =  0.0;
double _single_phase_inverter_rate_transition3_output__out =  0.0;
double _single_phase_inverter_vdc_mppt_mppt_rate_transition2_output__out =  0.0;
double _single_phase_inverter_vdc_mppt_mppt_rate_transition5_output__out =  0.0;
double _single_phase_inverter_vdc_mppt_rate_transition1_output__out =  0.0;
double _single_phase_inverter_rms_value2__square_sum;
double _single_phase_inverter_rms_value2__sample_cnt;
double _single_phase_inverter_rms_value2__period_cnt;
double _single_phase_inverter_rms_value2__db_timer;
double _single_phase_inverter_rms_value2__previous_filtered_value;
double _single_phase_inverter_rms_value2__previous_correction;
double _single_phase_inverter_rms_value2__previous_value;
double _single_phase_inverter_rms_value2__correction;
double _single_phase_inverter_rms_value2__filtered_value;
double _single_phase_inverter_rms_value2__out_state;
double _single_phase_inverter_rms_value1__square_sum;
double _single_phase_inverter_rms_value1__sample_cnt;
double _single_phase_inverter_rms_value1__period_cnt;
double _single_phase_inverter_rms_value1__db_timer;
double _single_phase_inverter_rms_value1__previous_filtered_value;
double _single_phase_inverter_rms_value1__previous_correction;
double _single_phase_inverter_rms_value1__previous_value;
double _single_phase_inverter_rms_value1__correction;
double _single_phase_inverter_rms_value1__filtered_value;
double _single_phase_inverter_rms_value1__out_state;
double _single_phase_inverter_current_controller_osg_discrete_transfer_function1__states[1];
double _single_phase_inverter_delay1__counter;
double _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__signQ;
double _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__signP;
double _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Sref;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d_integrator1__state;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d_integrator1__reset_state;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d2_integrator1__state;
double _single_phase_inverter_current_controller_dq_current_controller_pi_d2_integrator1__reset_state;
double _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__enable_old;
double _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__sum;
double _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__state;
X_Int32 _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__first_step;
double _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__state;
X_Int32 _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__first_step;
double _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__state;
X_Int32 _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__first_step;
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__states[1];
double _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__states[1];
double _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__S_PQref;
double _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__states[1];
double _single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__out_calc;
double _single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__reset_value;
//@cmp.svar.end

//
// Tunable parameters
//
static struct Tunable_params {
} __attribute__((__packed__)) tunable_params;

void *tunable_params_dev0_cpu0_ptr = &tunable_params;

// Dll function pointers
#if defined(_WIN64)
#else
// Define handles for loading dlls
#endif








// generated using template: virtual_hil/custom_functions.template---------------------------------
void ReInit_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rReInitTimer");
#endif
    //@cmp.init.block.start
    _single_phase_inverter_current_controller_limit_pqref_unit_delay1__state = 0.0;
    _single_phase_inverter_current_controller_limit_pqref_unit_delay2__state = 0.0;
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__P = 0;
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__Q = 0;
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__S = 0;
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__pf = 0;
    _single_phase_inverter_current_controller_single_phase_pll1_i__integrator_state =  0.0;
    _single_phase_inverter_current_controller_single_phase_pll1_i__filter_state =  0.0;
    _single_phase_inverter_current_controller_single_phase_pll1_integrator1__state = 0.0;
    _single_phase_inverter_current_controller_single_phase_pll1_integrator10__state = 55.0;
    _single_phase_inverter_current_controller_single_phase_pll1_integrator2__state = -200.0;
    _single_phase_inverter_current_controller_single_phase_pll1_integrator3__state = 200.0;
    _single_phase_inverter_current_controller_single_phase_pll1_integrator4__state = 200.0;
    _single_phase_inverter_current_controller_single_phase_pll1_integrator5__state = 345.57519189487726;
    _single_phase_inverter_current_controller_single_phase_pll1_integrator6__state = 345.57519189487726;
    _single_phase_inverter_current_controller_single_phase_pll1_integrator7__state = 55.0;
    _single_phase_inverter_current_controller_single_phase_pll1_integrator8__state = 55.0;
    _single_phase_inverter_current_controller_single_phase_pll1_integrator9__state = 55.0;
    _single_phase_inverter_rate_transition2_output__out =  0.0;
    _single_phase_inverter_rate_transition3_output__out =  0.0;
    _single_phase_inverter_vdc_mppt_mppt_rate_transition2_output__out =  0.0;
    _single_phase_inverter_vdc_mppt_mppt_rate_transition5_output__out =  0.0;
    _single_phase_inverter_vdc_mppt_rate_transition1_output__out =  0.0;
    HIL_OutAO(0x200f, 0.0f);
    HIL_OutAO(0x2011, 0.0f);
    HIL_OutAO(0x200d, 0.0f);
    HIL_OutAO(0x2010, 0.0f);
    HIL_OutAO(0x2014, 0.0f);
    HIL_OutAO(0x2013, 0.0f);
    _single_phase_inverter_rms_value2__square_sum = 0x0;
    _single_phase_inverter_rms_value2__sample_cnt = 0x0;
    _single_phase_inverter_rms_value2__period_cnt = 0x0;
    _single_phase_inverter_rms_value2__db_timer = 0x0;
    _single_phase_inverter_rms_value2__out = 0x0;
    _single_phase_inverter_rms_value2__previous_filtered_value = 0x0;
    _single_phase_inverter_rms_value2__previous_correction = 0x0;
    _single_phase_inverter_rms_value2__correction = 0x0;
    _single_phase_inverter_rms_value2__previous_value = 0x0;
    _single_phase_inverter_rms_value2__filtered_value = 0x0;
    _single_phase_inverter_rms_value2__out_state = 0x0;
    _single_phase_inverter_rms_value2__db_timer = 0x0;
    HIL_OutAO(0x2015, 0.0f);
    HIL_OutAO(0x2018, 0.0f);
    _single_phase_inverter_rms_value1__square_sum = 0x0;
    _single_phase_inverter_rms_value1__sample_cnt = 0x0;
    _single_phase_inverter_rms_value1__period_cnt = 0x0;
    _single_phase_inverter_rms_value1__db_timer = 0x0;
    _single_phase_inverter_rms_value1__out = 0x0;
    _single_phase_inverter_rms_value1__previous_filtered_value = 0x0;
    _single_phase_inverter_rms_value1__previous_correction = 0x0;
    _single_phase_inverter_rms_value1__correction = 0x0;
    _single_phase_inverter_rms_value1__previous_value = 0x0;
    _single_phase_inverter_rms_value1__filtered_value = 0x0;
    _single_phase_inverter_rms_value1__out_state = 0x0;
    _single_phase_inverter_rms_value1__db_timer = 0x0;
    HIL_OutAO(0x200e, 0.0f);
    HIL_OutAO(0x2012, 0.0f);
    X_UnInt32 _single_phase_inverter_current_controller_osg_discrete_transfer_function1__i;
    for (_single_phase_inverter_current_controller_osg_discrete_transfer_function1__i = 0; _single_phase_inverter_current_controller_osg_discrete_transfer_function1__i < 1; _single_phase_inverter_current_controller_osg_discrete_transfer_function1__i++) {
        _single_phase_inverter_current_controller_osg_discrete_transfer_function1__states[_single_phase_inverter_current_controller_osg_discrete_transfer_function1__i] = 0;
    }
    _single_phase_inverter_delay1__out = 0;
    _single_phase_inverter_delay1__counter = 0;
    _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Sref = 0;
    _single_phase_inverter_current_controller_dq_current_controller_pi_d_integrator1__state = 180.0;
    _single_phase_inverter_current_controller_dq_current_controller_pi_d_integrator1__reset_state = 2;
    _single_phase_inverter_current_controller_dq_current_controller_pi_d2_integrator1__state = 180.0;
    _single_phase_inverter_current_controller_dq_current_controller_pi_d2_integrator1__reset_state = 2;
    _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__sum = 0;
    _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__enable_old = 0;
    HIL_OutAO(0x2016, 0.0f);
    _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__state = 0;
    _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__first_step = 1;
    _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__state = 0;
    _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__first_step = 1;
    _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__state = 0;
    _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__first_step = 1;
    HIL_OutAO(0x2004, 0.0f);
    HIL_OutAO(0x2005, 0.0f);
    HIL_OutAO(0x2006, 0.0f);
    HIL_OutAO(0x2007, 0.0f);
    HIL_OutAO(0x2008, 0.0f);
    HIL_OutAO(0x2009, 0.0f);
    HIL_OutAO(0x200a, 0.0f);
    HIL_OutAO(0x200b, 0.0f);
    HIL_OutAO(0x200c, 0.0f);
    X_UnInt32 _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__i;
    for (_single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__i = 0; _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__i < 1; _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__i++) {
        _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__states[_single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__i] = 0;
    }
    X_UnInt32 _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__i;
    for (_single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__i = 0; _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__i < 1; _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__i++) {
        _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__states[_single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__i] = 0;
    }
    HIL_OutAO(0x2017, 0.0f);
    _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__S_PQref = 0;
    X_UnInt32 _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__i;
    for (_single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__i = 0; _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__i < 1; _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__i++) {
        _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__states[_single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__i] = 0;
    }
    _single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__out_calc = 0.0;
    _single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__reset_value = 2 * M_PI;
    _single_phase_inverter_single_phase_inverter_pwm_modulator__update_mask = 3;
    HIL_OutInt32(0x2000080 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[0], 4000);// divide by 2 is already implemented in hw
    HIL_OutInt32(0x20000c0 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[0], 160);
    HIL_OutInt32(0x2000080 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[1], 4000);// divide by 2 is already implemented in hw
    HIL_OutInt32(0x20000c0 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[1], 160);
    HIL_OutInt32(0x20001c0 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[0], 0);
    HIL_OutInt32(0x2000200 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[0], 0);
    HIL_OutInt32(0x20001c0 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[1], 0);
    HIL_OutInt32(0x2000200 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[1], 0);
    HIL_OutInt32(0x2000240 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[0], 0);
    HIL_OutInt32(0x2000240 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[1], 0);
    HIL_OutInt32(0x2000300 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[0], 1);
    HIL_OutInt32(0x2000300 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[1], 1);
    HIL_OutInt32(0x2000140, _single_phase_inverter_single_phase_inverter_pwm_modulator__update_mask);
    //@cmp.init.block.end
}


// Dll function pointers and dll reload function
#if defined(_WIN64)
// Define method for reloading dll functions
void ReloadDllFunctions_user_sp_cpu0_dev0(void) {
    // Load each library and setup function pointers
}

void FreeDllFunctions_user_sp_cpu0_dev0(void) {
}

#else
// Define method for reloading dll functions
void ReloadDllFunctions_user_sp_cpu0_dev0(void) {
    // Load each library and setup function pointers
}

void FreeDllFunctions_user_sp_cpu0_dev0(void) {
}
#endif

void load_fmi_libraries_user_sp_cpu0_dev0(void) {
#if defined(_WIN64)
#else
#endif
}


void ReInit_sp_scope_user_sp_cpu0_dev0() {
    // initialise SP Scope buffer pointer
}
// generated using template: common_timer_counter_handler.template-------------------------

/*****************************************************************************************/
/**
* This function is the handler which performs processing for the timer counter.
* It is called from an interrupt context such that the amount of processing
* performed should be minimized.  It is called when the timer counter expires
* if interrupts are enabled.
*
*
* @param    None
*
* @return   None
*
* @note     None
*
*****************************************************************************************/

void TimerCounterHandler_0_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rTimerCounterHandler_0");
#endif
    //////////////////////////////////////////////////////////////////////////
    // Set tunable parameters
    //////////////////////////////////////////////////////////////////////////
    // Generated from the component: Single Phase Inverter.Constant1
    // Generated from the component: Single Phase Inverter.Current controller.Constant3
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Constant2
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.const
    //////////////////////////////////////////////////////////////////////////
    // Output block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.out.block.start
    // Generated from the component: PV_in.Connect
    _pv_in_connect__out = XIo_InFloat(0x55000120);
    // Generated from the component: PV_in.Enable
    _pv_in_enable__out = XIo_InFloat(0x55000124);
    // Generated from the component: PV_in.Q_mode
    _pv_in_q_mode__out = XIo_InFloat(0x55000128);
    // Generated from the component: PV_in.Q_ref
    _pv_in_q_ref__out = XIo_InFloat(0x5500012c);
    // Generated from the component: Single Phase Inverter.Constant1
    // Generated from the component: Single Phase Inverter.Current controller.Constant3
    // Generated from the component: Single Phase Inverter.Current controller.Limit_PQref.Unit Delay1
    _single_phase_inverter_current_controller_limit_pqref_unit_delay1__out = _single_phase_inverter_current_controller_limit_pqref_unit_delay1__state;
    // Generated from the component: Single Phase Inverter.Current controller.Limit_PQref.Unit Delay2
    _single_phase_inverter_current_controller_limit_pqref_unit_delay2__out = _single_phase_inverter_current_controller_limit_pqref_unit_delay2__state;
    // Generated from the component: Single Phase Inverter.Current controller.Power_Meas.Gain4
    _single_phase_inverter_current_controller_power_meas_gain4__out = 20000.0 * _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__out;
    // Generated from the component: Single Phase Inverter.Current controller.Power_Meas.Gain5
    _single_phase_inverter_current_controller_power_meas_gain5__out = 20000.0 * _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__out;
    // Generated from the component: Single Phase Inverter.Current controller.Power_Meas.Power_Meas_DQpu.S_and_pf
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__P = _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__out;
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__Q = _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__out;
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__S = sqrt(_single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__P * _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__P + _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__Q * _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__Q);
    if (_single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__S > 0) {
        _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__pf = _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__P / _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__S;
    }
    else {
        _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__pf = 0;
    }
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Constant2
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.I
    _single_phase_inverter_current_controller_single_phase_pll1_i__pi_reg_out_int = _single_phase_inverter_current_controller_single_phase_pll1_i__integrator_state;
    if (_single_phase_inverter_current_controller_single_phase_pll1_i__pi_reg_out_int < -62.83185307179586)
        _single_phase_inverter_current_controller_single_phase_pll1_i__av_active = -1;
    else if (_single_phase_inverter_current_controller_single_phase_pll1_i__pi_reg_out_int > 62.83185307179586)
        _single_phase_inverter_current_controller_single_phase_pll1_i__av_active = 1;
    else
        _single_phase_inverter_current_controller_single_phase_pll1_i__av_active = 0;
    _single_phase_inverter_current_controller_single_phase_pll1_i__out = MIN(MAX(_single_phase_inverter_current_controller_single_phase_pll1_i__pi_reg_out_int, -62.83185307179586), 62.83185307179586);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator1
    _single_phase_inverter_current_controller_single_phase_pll1_integrator1__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator1__state;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator10
    _single_phase_inverter_current_controller_single_phase_pll1_integrator10__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator10__state;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator2
    _single_phase_inverter_current_controller_single_phase_pll1_integrator2__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator2__state;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator3
    _single_phase_inverter_current_controller_single_phase_pll1_integrator3__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator3__state;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator4
    _single_phase_inverter_current_controller_single_phase_pll1_integrator4__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator4__state;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator5
    _single_phase_inverter_current_controller_single_phase_pll1_integrator5__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator5__state;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator6
    _single_phase_inverter_current_controller_single_phase_pll1_integrator6__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator6__state;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator7
    _single_phase_inverter_current_controller_single_phase_pll1_integrator7__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator7__state;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator8
    _single_phase_inverter_current_controller_single_phase_pll1_integrator8__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator8__state;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator9
    _single_phase_inverter_current_controller_single_phase_pll1_integrator9__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator9__state;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Trigonometric function1
    _single_phase_inverter_current_controller_single_phase_pll1_trigonometric_function1__out = sin(_single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__out);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.const
    // Generated from the component: Single Phase Inverter.Iout.Ia1
    _single_phase_inverter_iout_ia1__out = (HIL_InFloat(0xc80000 + 0xc));
    // Generated from the component: Single Phase Inverter.Vdc.Va1
    _single_phase_inverter_vdc_va1__out = (HIL_InFloat(0xc80000 + 0x6));
    // Generated from the component: Single Phase Inverter.Vout.Va1
    _single_phase_inverter_vout_va1__out = (HIL_InFloat(0xc80000 + 0x8));
    // Generated from the component: PV_in.Bus Join1
    _pv_in_bus_join1__out[0] = _pv_in_connect__out;
    _pv_in_bus_join1__out[1] = _pv_in_enable__out;
    _pv_in_bus_join1__out[2] = _pv_in_q_mode__out;
    _pv_in_bus_join1__out[3] = _pv_in_q_ref__out;
    // Generated from the component: Single Phase Inverter.Current controller.Pref
    HIL_OutAO(0x200f, (float)_single_phase_inverter_current_controller_limit_pqref_unit_delay1__out);
    // Generated from the component: Single Phase Inverter.Current controller.Qref
    HIL_OutAO(0x2011, (float)_single_phase_inverter_current_controller_limit_pqref_unit_delay2__out);
    // Generated from the component: Single Phase Inverter.Current controller.Gain7
    _single_phase_inverter_current_controller_gain7__out = 5e-05 * _single_phase_inverter_current_controller_power_meas_gain4__out;
    // Generated from the component: Single Phase Inverter.Current controller.P
    HIL_OutAO(0x200d, (float)_single_phase_inverter_current_controller_power_meas_gain4__out);
    // Generated from the component: Single Phase Inverter.Current controller.Q
    HIL_OutAO(0x2010, (float)_single_phase_inverter_current_controller_power_meas_gain5__out);
    // Generated from the component: Single Phase Inverter.Current controller.Power_Meas.Gain6
    _single_phase_inverter_current_controller_power_meas_gain6__out = 20000.0 * _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__S;
    // Generated from the component: Single Phase Inverter.Current controller.pf
    HIL_OutAO(0x2014, (float)_single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__pf);
    // Generated from the component: Single Phase Inverter.Current controller.f_meas
    HIL_OutAO(0x2013, (float)_single_phase_inverter_current_controller_single_phase_pll1_integrator10__out);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.C function1
    _single_phase_inverter_current_controller_single_phase_pll1_c_function1__theta_dq = _single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__out;
    _single_phase_inverter_current_controller_single_phase_pll1_c_function1__va = _single_phase_inverter_current_controller_single_phase_pll1_integrator1__out;
    _single_phase_inverter_current_controller_single_phase_pll1_c_function1__vb = _single_phase_inverter_current_controller_single_phase_pll1_integrator2__out;
    _single_phase_inverter_current_controller_single_phase_pll1_c_function1__vq = cos(_single_phase_inverter_current_controller_single_phase_pll1_c_function1__theta_dq) * _single_phase_inverter_current_controller_single_phase_pll1_c_function1__va + sin(_single_phase_inverter_current_controller_single_phase_pll1_c_function1__theta_dq) * _single_phase_inverter_current_controller_single_phase_pll1_c_function1__vb;
    _single_phase_inverter_current_controller_single_phase_pll1_c_function1__vd = -sin(_single_phase_inverter_current_controller_single_phase_pll1_c_function1__theta_dq) * _single_phase_inverter_current_controller_single_phase_pll1_c_function1__va + cos(_single_phase_inverter_current_controller_single_phase_pll1_c_function1__theta_dq) * _single_phase_inverter_current_controller_single_phase_pll1_c_function1__vb;
    // Generated from the component: Single Phase Inverter.Current controller.Current_ref1.Limit5
    _single_phase_inverter_current_controller_current_ref1_limit5__out = MAX(_single_phase_inverter_current_controller_single_phase_pll1_integrator4__out, 0.01);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Sum4
    _single_phase_inverter_current_controller_single_phase_pll1_sum4__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator3__out - _single_phase_inverter_current_controller_single_phase_pll1_integrator4__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Product2
    _single_phase_inverter_current_controller_single_phase_pll1_product2__out = (_single_phase_inverter_current_controller_single_phase_pll1_integrator5__out * _single_phase_inverter_current_controller_single_phase_pll1_integrator1__out);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.w_to_f
    _single_phase_inverter_current_controller_single_phase_pll1_w_to_f__out = 0.15915494309189535 * _single_phase_inverter_current_controller_single_phase_pll1_integrator5__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Sum9
    _single_phase_inverter_current_controller_single_phase_pll1_sum9__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator6__out - _single_phase_inverter_current_controller_single_phase_pll1_integrator5__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Sum11
    _single_phase_inverter_current_controller_single_phase_pll1_sum11__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator7__out - _single_phase_inverter_current_controller_single_phase_pll1_integrator8__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Sum13
    _single_phase_inverter_current_controller_single_phase_pll1_sum13__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator8__out - _single_phase_inverter_current_controller_single_phase_pll1_integrator9__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Sum14
    _single_phase_inverter_current_controller_single_phase_pll1_sum14__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator9__out - _single_phase_inverter_current_controller_single_phase_pll1_integrator10__out;
    // Generated from the component: Single Phase Inverter.Current controller.Termination1
    // Generated from the component: Single Phase Inverter.Current controller.Gain6
    _single_phase_inverter_current_controller_gain6__out = 0.008131727983645295 * _single_phase_inverter_iout_ia1__out;
    // Generated from the component: Single Phase Inverter.RMS value2
    _single_phase_inverter_rms_value2__previous_filtered_value = _single_phase_inverter_rms_value2__filtered_value;
    if (0)
        _single_phase_inverter_rms_value2__filtered_value = _single_phase_inverter_rms_value2__previous_filtered_value * 1 + _single_phase_inverter_iout_ia1__out * 1;
    else
        _single_phase_inverter_rms_value2__filtered_value = _single_phase_inverter_rms_value2__previous_filtered_value * 0.1 + _single_phase_inverter_iout_ia1__out * 0.9;
    _single_phase_inverter_rms_value2__db_timer += 0.0001;
    if( (_single_phase_inverter_rms_value2__filtered_value >= 0.0) && (_single_phase_inverter_rms_value2__previous_filtered_value < 0.0) && (_single_phase_inverter_rms_value2__db_timer >= 0.0) ) {
        _single_phase_inverter_rms_value2__zc = 1;
        _single_phase_inverter_rms_value2__db_timer = 0;
    } else
        _single_phase_inverter_rms_value2__zc = 0;
    _single_phase_inverter_rms_value2__out = _single_phase_inverter_rms_value2__out_state;
    // Generated from the component: Single Phase Inverter.Limit5
    _single_phase_inverter_limit5__out = MAX(_single_phase_inverter_vdc_va1__out, 0.01);
    // Generated from the component: Single Phase Inverter.Current controller.Gain1
    _single_phase_inverter_current_controller_gain1__out = 5e-05 * _single_phase_inverter_vdc_mppt_rate_transition1_output__out;
    // Generated from the component: Single Phase Inverter.Current controller.Gain3
    _single_phase_inverter_current_controller_gain3__out = 0.003074377309506728 * _single_phase_inverter_vout_va1__out;
    // Generated from the component: Single Phase Inverter.RMS value1
    _single_phase_inverter_rms_value1__previous_filtered_value = _single_phase_inverter_rms_value1__filtered_value;
    if (0)
        _single_phase_inverter_rms_value1__filtered_value = _single_phase_inverter_rms_value1__previous_filtered_value * 1 + _single_phase_inverter_vout_va1__out * 1;
    else
        _single_phase_inverter_rms_value1__filtered_value = _single_phase_inverter_rms_value1__previous_filtered_value * 0.1 + _single_phase_inverter_vout_va1__out * 0.9;
    _single_phase_inverter_rms_value1__db_timer += 0.0001;
    if( (_single_phase_inverter_rms_value1__filtered_value >= 0.0) && (_single_phase_inverter_rms_value1__previous_filtered_value < 0.0) && (_single_phase_inverter_rms_value1__db_timer >= 0.0) ) {
        _single_phase_inverter_rms_value1__zc = 1;
        _single_phase_inverter_rms_value1__db_timer = 0;
    } else
        _single_phase_inverter_rms_value1__zc = 0;
    _single_phase_inverter_rms_value1__out = _single_phase_inverter_rms_value1__out_state;
    // Generated from the component: Single Phase Inverter.Input.Bus Split2
    _single_phase_inverter_input_bus_split2__out = _pv_in_bus_join1__out[0];
    _single_phase_inverter_input_bus_split2__out1 = _pv_in_bus_join1__out[1];
    _single_phase_inverter_input_bus_split2__out2 = _pv_in_bus_join1__out[2];
    _single_phase_inverter_input_bus_split2__out3 = _pv_in_bus_join1__out[3];
    // Generated from the component: Single Phase Inverter.Current controller.P_pu
    HIL_OutAO(0x200e, (float)_single_phase_inverter_current_controller_gain7__out);
    // Generated from the component: Single Phase Inverter.Current controller.S
    HIL_OutAO(0x2012, (float)_single_phase_inverter_current_controller_power_meas_gain6__out);
    // Generated from the component: Single Phase Inverter.Current controller.Current_ref1.Limit4
    _single_phase_inverter_current_controller_current_ref1_limit4__out = MAX(_single_phase_inverter_current_controller_single_phase_pll1_c_function1__vq, 0.01);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Gain3
    _single_phase_inverter_current_controller_single_phase_pll1_gain3__out = -1.0 * _single_phase_inverter_current_controller_single_phase_pll1_c_function1__vd;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Math_f1
    _single_phase_inverter_current_controller_single_phase_pll1_math_f1__out = pow(_single_phase_inverter_current_controller_single_phase_pll1_c_function1__vq, _single_phase_inverter_current_controller_single_phase_pll1_constant2__out);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Math_f2
    _single_phase_inverter_current_controller_single_phase_pll1_math_f2__out = pow(_single_phase_inverter_current_controller_single_phase_pll1_c_function1__vd, _single_phase_inverter_current_controller_single_phase_pll1_constant2__out);
    // Generated from the component: Single Phase Inverter.Current controller.Current_ref1.Product4
    _single_phase_inverter_current_controller_current_ref1_product4__out = (_single_phase_inverter_current_controller_current_ref1_limit5__out * _single_phase_inverter_current_controller_limit_pqref_unit_delay2__out);
    // Generated from the component: Single Phase Inverter.Current controller.Current_ref1.Product5
    _single_phase_inverter_current_controller_current_ref1_product5__out = (_single_phase_inverter_current_controller_limit_pqref_unit_delay1__out * _single_phase_inverter_current_controller_current_ref1_limit5__out);
    // Generated from the component: Single Phase Inverter.Current controller.Current_ref1.squared_Vt.Product1
    _single_phase_inverter_current_controller_current_ref1_squared_vt_product1__out = (_single_phase_inverter_current_controller_current_ref1_limit5__out * _single_phase_inverter_current_controller_current_ref1_limit5__out);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Gain5
    _single_phase_inverter_current_controller_single_phase_pll1_gain5__out = 62.83185307179586 * _single_phase_inverter_current_controller_single_phase_pll1_sum4__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Sum12
    _single_phase_inverter_current_controller_single_phase_pll1_sum12__out = _single_phase_inverter_current_controller_single_phase_pll1_w_to_f__out - _single_phase_inverter_current_controller_single_phase_pll1_integrator7__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Gain7
    _single_phase_inverter_current_controller_single_phase_pll1_gain7__out = 628.3185307179587 * _single_phase_inverter_current_controller_single_phase_pll1_sum9__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Gain8
    _single_phase_inverter_current_controller_single_phase_pll1_gain8__out = 62.83185307179586 * _single_phase_inverter_current_controller_single_phase_pll1_sum11__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Gain10
    _single_phase_inverter_current_controller_single_phase_pll1_gain10__out = 62.83185307179586 * _single_phase_inverter_current_controller_single_phase_pll1_sum13__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Gain11
    _single_phase_inverter_current_controller_single_phase_pll1_gain11__out = 62.83185307179586 * _single_phase_inverter_current_controller_single_phase_pll1_sum14__out;
    // Generated from the component: Single Phase Inverter.Current controller.OSG.Discrete Transfer Function1
    X_UnInt32 _single_phase_inverter_current_controller_osg_discrete_transfer_function1__i;
    _single_phase_inverter_current_controller_osg_discrete_transfer_function1__a_sum = 0.0f;
    _single_phase_inverter_current_controller_osg_discrete_transfer_function1__b_sum = 0.0f;
    _single_phase_inverter_current_controller_osg_discrete_transfer_function1__delay_line_in = 0.0f;
    for (_single_phase_inverter_current_controller_osg_discrete_transfer_function1__i = 0; _single_phase_inverter_current_controller_osg_discrete_transfer_function1__i < 1; _single_phase_inverter_current_controller_osg_discrete_transfer_function1__i++) {
        _single_phase_inverter_current_controller_osg_discrete_transfer_function1__b_sum += _single_phase_inverter_current_controller_osg_discrete_transfer_function1__b_coeff[_single_phase_inverter_current_controller_osg_discrete_transfer_function1__i + 1] * _single_phase_inverter_current_controller_osg_discrete_transfer_function1__states[_single_phase_inverter_current_controller_osg_discrete_transfer_function1__i];
    }
    _single_phase_inverter_current_controller_osg_discrete_transfer_function1__a_sum += _single_phase_inverter_current_controller_osg_discrete_transfer_function1__states[0] * _single_phase_inverter_current_controller_osg_discrete_transfer_function1__a_coeff[1];
    _single_phase_inverter_current_controller_osg_discrete_transfer_function1__delay_line_in = _single_phase_inverter_current_controller_gain6__out - _single_phase_inverter_current_controller_osg_discrete_transfer_function1__a_sum;
    _single_phase_inverter_current_controller_osg_discrete_transfer_function1__b_sum += _single_phase_inverter_current_controller_osg_discrete_transfer_function1__b_coeff[0] * _single_phase_inverter_current_controller_osg_discrete_transfer_function1__delay_line_in;
    _single_phase_inverter_current_controller_osg_discrete_transfer_function1__out = _single_phase_inverter_current_controller_osg_discrete_transfer_function1__b_sum;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.Limit3
    _single_phase_inverter_current_controller_dq_current_controller_limit3__out = MAX(_single_phase_inverter_limit5__out, 0.01);
    // Generated from the component: Single Phase Inverter.Rate Transition2.Input
    _single_phase_inverter_rate_transition2_output__out = _single_phase_inverter_limit5__out;
    // Generated from the component: Single Phase Inverter.Current controller.Gain8
    _single_phase_inverter_current_controller_gain8__out = 0.9259259259259258 * _single_phase_inverter_current_controller_gain3__out;
    // Generated from the component: Single Phase Inverter.Q_mode
    HIL_OutInt32(0xf00401, _single_phase_inverter_input_bus_split2__out2 != 0x0);
    // Generated from the component: Single Phase Inverter.S1.CTC_Wrapper
    if (_single_phase_inverter_input_bus_split2__out == 0x0) {
        HIL_OutInt32(0x8240480, 0x0);
    }
    else {
        HIL_OutInt32(0x8240480, 0x1);
    }
    // Generated from the component: Single Phase Inverter.Signal switch1
    _single_phase_inverter_signal_switch1__out = (_single_phase_inverter_input_bus_split2__out2 < 0.5f) ? _single_phase_inverter_constant1__out : _single_phase_inverter_input_bus_split2__out3;
    // Generated from the component: Single Phase Inverter.delay1
    _single_phase_inverter_delay1__in = _single_phase_inverter_input_bus_split2__out;
    if (_single_phase_inverter_delay1__out == 0) {
        if (_single_phase_inverter_delay1__in > 0.5) {
            _single_phase_inverter_delay1__counter += 0.0001;
            if (_single_phase_inverter_delay1__counter > 0.5) {
                _single_phase_inverter_delay1__out = 1;
            }
        }
        else {
            _single_phase_inverter_delay1__counter -= _single_phase_inverter_delay1__counter;
            _single_phase_inverter_delay1__out = 0;
        }
    }
    else {
        _single_phase_inverter_delay1__counter = 0;
        if (_single_phase_inverter_delay1__in <= 0.5) {
            _single_phase_inverter_delay1__out = 0;
        }
    }
    // Generated from the component: Single Phase Inverter.Current controller.Current_ref1.Product3
    _single_phase_inverter_current_controller_current_ref1_product3__out = (_single_phase_inverter_current_controller_current_ref1_limit4__out * _single_phase_inverter_current_controller_limit_pqref_unit_delay1__out);
    // Generated from the component: Single Phase Inverter.Current controller.Current_ref1.Product6
    _single_phase_inverter_current_controller_current_ref1_product6__out = (_single_phase_inverter_current_controller_limit_pqref_unit_delay2__out * _single_phase_inverter_current_controller_current_ref1_limit4__out);
    // Generated from the component: Single Phase Inverter.Current controller.Current_ref1.squared_Vt.Product2
    _single_phase_inverter_current_controller_current_ref1_squared_vt_product2__out = (_single_phase_inverter_current_controller_current_ref1_limit4__out * _single_phase_inverter_current_controller_current_ref1_limit4__out);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Sum7
    _single_phase_inverter_current_controller_single_phase_pll1_sum7__out = _single_phase_inverter_current_controller_single_phase_pll1_gain3__out - _single_phase_inverter_current_controller_single_phase_pll1_integrator3__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Sum6
    _single_phase_inverter_current_controller_single_phase_pll1_sum6__out = _single_phase_inverter_current_controller_single_phase_pll1_math_f1__out + _single_phase_inverter_current_controller_single_phase_pll1_math_f2__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Gain9
    _single_phase_inverter_current_controller_single_phase_pll1_gain9__out = 62.83185307179586 * _single_phase_inverter_current_controller_single_phase_pll1_sum12__out;
    // Generated from the component: Single Phase Inverter.Current controller.alpha beta to dq2
    _single_phase_inverter_current_controller_alpha_beta_to_dq2__k1 = cos(_single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__out);
    _single_phase_inverter_current_controller_alpha_beta_to_dq2__k2 = sin(_single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__out);
    _single_phase_inverter_current_controller_alpha_beta_to_dq2__d = _single_phase_inverter_current_controller_alpha_beta_to_dq2__k2 * _single_phase_inverter_current_controller_gain6__out - _single_phase_inverter_current_controller_alpha_beta_to_dq2__k1 * _single_phase_inverter_current_controller_osg_discrete_transfer_function1__out;
    _single_phase_inverter_current_controller_alpha_beta_to_dq2__q = _single_phase_inverter_current_controller_alpha_beta_to_dq2__k1 * _single_phase_inverter_current_controller_gain6__out + _single_phase_inverter_current_controller_alpha_beta_to_dq2__k2 * _single_phase_inverter_current_controller_osg_discrete_transfer_function1__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Sum1
    _single_phase_inverter_current_controller_single_phase_pll1_sum1__out =  - _single_phase_inverter_current_controller_single_phase_pll1_integrator1__out + _single_phase_inverter_current_controller_gain8__out;
    // Generated from the component: Single Phase Inverter.Current controller.Gain2
    _single_phase_inverter_current_controller_gain2__out = 5e-05 * _single_phase_inverter_signal_switch1__out;
    // Generated from the component: Single Phase Inverter.Logical operator2
    _single_phase_inverter_logical_operator2__out = _single_phase_inverter_input_bus_split2__out1 && _single_phase_inverter_delay1__out ;
    // Generated from the component: Single Phase Inverter.Current controller.Current_ref1.Sum3
    _single_phase_inverter_current_controller_current_ref1_sum3__out = _single_phase_inverter_current_controller_current_ref1_product3__out - _single_phase_inverter_current_controller_current_ref1_product4__out;
    // Generated from the component: Single Phase Inverter.Current controller.Current_ref1.Sum4
    _single_phase_inverter_current_controller_current_ref1_sum4__out = _single_phase_inverter_current_controller_current_ref1_product5__out + _single_phase_inverter_current_controller_current_ref1_product6__out;
    // Generated from the component: Single Phase Inverter.Current controller.Current_ref1.squared_Vt.Sum3
    _single_phase_inverter_current_controller_current_ref1_squared_vt_sum3__out = _single_phase_inverter_current_controller_current_ref1_squared_vt_product1__out + _single_phase_inverter_current_controller_current_ref1_squared_vt_product2__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Gain4
    _single_phase_inverter_current_controller_single_phase_pll1_gain4__out = 62.83185307179586 * _single_phase_inverter_current_controller_single_phase_pll1_sum7__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Math1
    _single_phase_inverter_current_controller_single_phase_pll1_math1__out = sqrt(_single_phase_inverter_current_controller_single_phase_pll1_sum6__out);
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.Gain4
    _single_phase_inverter_current_controller_dq_current_controller_gain4__out = 0.12073051462386863 * _single_phase_inverter_current_controller_alpha_beta_to_dq2__q;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.Gain7
    _single_phase_inverter_current_controller_dq_current_controller_gain7__out = 0.12073051462386863 * _single_phase_inverter_current_controller_alpha_beta_to_dq2__d;
    // Generated from the component: Single Phase Inverter.Current controller.Power_Meas.Power_Meas_DQpu.Product1
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_product1__out = (_single_phase_inverter_current_controller_single_phase_pll1_integrator4__out * _single_phase_inverter_current_controller_alpha_beta_to_dq2__d);
    // Generated from the component: Single Phase Inverter.Current controller.Power_Meas.Power_Meas_DQpu.Product2
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_product2__out = (_single_phase_inverter_current_controller_single_phase_pll1_c_function1__vq * _single_phase_inverter_current_controller_alpha_beta_to_dq2__q);
    // Generated from the component: Single Phase Inverter.Current controller.Power_Meas.Power_Meas_DQpu.Product3
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_product3__out = (_single_phase_inverter_current_controller_single_phase_pll1_integrator4__out * _single_phase_inverter_current_controller_alpha_beta_to_dq2__q);
    // Generated from the component: Single Phase Inverter.Current controller.Power_Meas.Power_Meas_DQpu.Product4
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_product4__out = (_single_phase_inverter_current_controller_single_phase_pll1_c_function1__vq * _single_phase_inverter_current_controller_alpha_beta_to_dq2__d);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Gain2
    _single_phase_inverter_current_controller_single_phase_pll1_gain2__out = 0.4 * _single_phase_inverter_current_controller_single_phase_pll1_sum1__out;
    // Generated from the component: Single Phase Inverter.Current controller.Limit_PQref.priority_PQlim.PQ limiting with priority
    _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref = _single_phase_inverter_current_controller_gain1__out;
    _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref = _single_phase_inverter_current_controller_gain2__out;
    _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax = _single_phase_inverter_current_controller_constant3__out;
    _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Sref = sqrt(_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref * _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref + _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref * _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref);
    if (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref >= 0)_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__signQ = 1;
    else _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__signQ = -1;
    if (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref >= 0)_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__signP = 1;
    else _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__signP = -1;
    if (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Sref <= _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax) {
        _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__S = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Sref;
        _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__P = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref;
        _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref;
    }
    else {
        _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__S = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax;
        if (1.0 == 1) {
            if (fabs(_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref) > _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax) {
                _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__P = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__signP * _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax;
                _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q = 0;
            }
            else {
                _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__P = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref;
                _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__signQ * sqrt(_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax * _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax - _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref * _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref);
            }
        }
        else if (1.0 == 2) {
            if (fabs(_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref) > _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax) {
                _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__signQ * _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax;
                _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__P = 0;
            }
            else {
                _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref;
                _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__P = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__signP * sqrt(_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax * _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax - _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref * _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref);
            }
        }
        else {
            _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__P = (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Pref / _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Sref) * _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax;
            _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q = (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Qref / _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Sref) * _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Smax;
        }
    }
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d.Integrator1
    if (((_single_phase_inverter_logical_operator2__out > 0.0) && (_single_phase_inverter_current_controller_dq_current_controller_pi_d_integrator1__reset_state <= 0)) || ((_single_phase_inverter_logical_operator2__out <= 0.0) && (_single_phase_inverter_current_controller_dq_current_controller_pi_d_integrator1__reset_state == 1))) {
        _single_phase_inverter_current_controller_dq_current_controller_pi_d_integrator1__state = 180.0;
    }
    _single_phase_inverter_current_controller_dq_current_controller_pi_d_integrator1__out = _single_phase_inverter_current_controller_dq_current_controller_pi_d_integrator1__state;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d2.Integrator1
    if (((_single_phase_inverter_logical_operator2__out > 0.0) && (_single_phase_inverter_current_controller_dq_current_controller_pi_d2_integrator1__reset_state <= 0)) || ((_single_phase_inverter_logical_operator2__out <= 0.0) && (_single_phase_inverter_current_controller_dq_current_controller_pi_d2_integrator1__reset_state == 1))) {
        _single_phase_inverter_current_controller_dq_current_controller_pi_d2_integrator1__state = 180.0;
    }
    _single_phase_inverter_current_controller_dq_current_controller_pi_d2_integrator1__out = _single_phase_inverter_current_controller_dq_current_controller_pi_d2_integrator1__state;
    // Generated from the component: Single Phase Inverter.On_inv
    HIL_OutInt32(0xf00400, _single_phase_inverter_logical_operator2__out != 0x0);
    // Generated from the component: Single Phase Inverter.Output.Bus Join1
    _single_phase_inverter_output_bus_join1__out[0] = _single_phase_inverter_input_bus_split2__out;
    _single_phase_inverter_output_bus_join1__out[1] = _single_phase_inverter_logical_operator2__out;
    _single_phase_inverter_output_bus_join1__out[2] = _single_phase_inverter_rms_value1__out;
    _single_phase_inverter_output_bus_join1__out[3] = _single_phase_inverter_rms_value2__out;
    _single_phase_inverter_output_bus_join1__out[4] = _single_phase_inverter_current_controller_single_phase_pll1_integrator10__out;
    _single_phase_inverter_output_bus_join1__out[5] = _single_phase_inverter_current_controller_power_meas_gain4__out;
    _single_phase_inverter_output_bus_join1__out[6] = _single_phase_inverter_current_controller_power_meas_gain5__out;
    _single_phase_inverter_output_bus_join1__out[7] = _single_phase_inverter_current_controller_power_meas_gain6__out;
    _single_phase_inverter_output_bus_join1__out[8] = _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_s_and_pf__pf;
    // Generated from the component: Single Phase Inverter.Rate Transition3.Input
    _single_phase_inverter_rate_transition3_output__out = _single_phase_inverter_logical_operator2__out;
    // Generated from the component: Single Phase Inverter.Current controller.Current_ref1.Limit3
    _single_phase_inverter_current_controller_current_ref1_limit3__out = MAX(_single_phase_inverter_current_controller_current_ref1_squared_vt_sum3__out, 0.01);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Limit1
    _single_phase_inverter_current_controller_single_phase_pll1_limit1__out = MAX(_single_phase_inverter_current_controller_single_phase_pll1_math1__out, 1e-05);
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.Product1
    _single_phase_inverter_current_controller_dq_current_controller_product1__out = (_single_phase_inverter_current_controller_single_phase_pll1_integrator10__out * _single_phase_inverter_current_controller_dq_current_controller_gain4__out);
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.Product6
    _single_phase_inverter_current_controller_dq_current_controller_product6__out = (_single_phase_inverter_current_controller_dq_current_controller_gain7__out * _single_phase_inverter_current_controller_single_phase_pll1_integrator10__out);
    // Generated from the component: Single Phase Inverter.Current controller.Power_Meas.Power_Meas_DQpu.Sum1
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_sum1__out = _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_product1__out + _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_product2__out;
    // Generated from the component: Single Phase Inverter.Current controller.Power_Meas.Power_Meas_DQpu.Sum2
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_sum2__out = _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_product4__out - _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_product3__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Sum2
    _single_phase_inverter_current_controller_single_phase_pll1_sum2__out = _single_phase_inverter_current_controller_single_phase_pll1_gain2__out - _single_phase_inverter_current_controller_single_phase_pll1_integrator2__out;
    // Generated from the component: Single Phase Inverter.Current controller.Limit_PQref.P rate limit
    if (_single_phase_inverter_current_controller_limit_pqref_p_rate_limit__first_step) {
        _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__out = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__P;
        _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__state = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__P;
    } else {
        _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__out = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__P;
        if (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__P - _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__state > 0.0005)
            _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__out = _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__state + (0.0005);
        if (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__P - _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__state < -0.0005)
            _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__out = _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__state + (-0.0005);
    }
    // Generated from the component: Single Phase Inverter.Current controller.Limit_PQref.Q rate limit
    if (_single_phase_inverter_current_controller_limit_pqref_q_rate_limit__first_step) {
        _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__out = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q;
        _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__state = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q;
    } else {
        _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__out = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q;
        if (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q - _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__state > 0.0005)
            _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__out = _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__state + (0.0005);
        if (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q - _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__state < -0.0005)
            _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__out = _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__state + (-0.0005);
    }
    // Generated from the component: Single Phase Inverter.Current controller.Limit_PQref.S rate limit
    if (_single_phase_inverter_current_controller_limit_pqref_s_rate_limit__first_step) {
        _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__out = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__S;
        _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__state = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__S;
    } else {
        _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__out = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__S;
        if (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__S - _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__state > 0.0005)
            _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__out = _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__state + (0.0005);
        if (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__S - _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__state < -0.0005)
            _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__out = _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__state + (-0.0005);
    }
    // Generated from the component: PV_out.Out
    HIL_OutAO(0x2004, (float)_single_phase_inverter_output_bus_join1__out[0]);
    HIL_OutAO(0x2005, (float)_single_phase_inverter_output_bus_join1__out[1]);
    HIL_OutAO(0x2006, (float)_single_phase_inverter_output_bus_join1__out[2]);
    HIL_OutAO(0x2007, (float)_single_phase_inverter_output_bus_join1__out[3]);
    HIL_OutAO(0x2008, (float)_single_phase_inverter_output_bus_join1__out[4]);
    HIL_OutAO(0x2009, (float)_single_phase_inverter_output_bus_join1__out[5]);
    HIL_OutAO(0x200a, (float)_single_phase_inverter_output_bus_join1__out[6]);
    HIL_OutAO(0x200b, (float)_single_phase_inverter_output_bus_join1__out[7]);
    HIL_OutAO(0x200c, (float)_single_phase_inverter_output_bus_join1__out[8]);
    // Generated from the component: Single Phase Inverter.Current controller.Current_ref1.Product1
    _single_phase_inverter_current_controller_current_ref1_product1__out = (_single_phase_inverter_current_controller_current_ref1_sum3__out) * 1.0 / (_single_phase_inverter_current_controller_current_ref1_limit3__out);
    // Generated from the component: Single Phase Inverter.Current controller.Current_ref1.Product2
    _single_phase_inverter_current_controller_current_ref1_product2__out = (_single_phase_inverter_current_controller_current_ref1_sum4__out) * 1.0 / (_single_phase_inverter_current_controller_current_ref1_limit3__out);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Product8
    _single_phase_inverter_current_controller_single_phase_pll1_product8__out = (_single_phase_inverter_current_controller_single_phase_pll1_c_function1__vq) * 1.0 / (_single_phase_inverter_current_controller_single_phase_pll1_limit1__out);
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.Sum10
    _single_phase_inverter_current_controller_dq_current_controller_sum10__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator4__out - _single_phase_inverter_current_controller_dq_current_controller_product1__out;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.Sum13
    _single_phase_inverter_current_controller_dq_current_controller_sum13__out = _single_phase_inverter_current_controller_dq_current_controller_product6__out + _single_phase_inverter_current_controller_single_phase_pll1_c_function1__vq;
    // Generated from the component: Single Phase Inverter.Current controller.Power_Meas.Power_Meas_DQpu.LPF_P
    X_UnInt32 _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__i;
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__a_sum = 0.0f;
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__b_sum = 0.0f;
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__delay_line_in = 0.0f;
    for (_single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__i = 0; _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__i < 1; _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__i++) {
        _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__b_sum += _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__b_coeff[_single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__i + 1] * _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__states[_single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__i];
    }
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__a_sum += _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__states[0] * _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__a_coeff[1];
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__delay_line_in = _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_sum1__out - _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__a_sum;
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__b_sum += _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__b_coeff[0] * _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__delay_line_in;
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__out = _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__b_sum;
    // Generated from the component: Single Phase Inverter.Current controller.Power_Meas.Power_Meas_DQpu.LPF_Q
    X_UnInt32 _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__i;
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__a_sum = 0.0f;
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__b_sum = 0.0f;
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__delay_line_in = 0.0f;
    for (_single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__i = 0; _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__i < 1; _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__i++) {
        _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__b_sum += _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__b_coeff[_single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__i + 1] * _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__states[_single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__i];
    }
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__a_sum += _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__states[0] * _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__a_coeff[1];
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__delay_line_in = _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_sum2__out - _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__a_sum;
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__b_sum += _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__b_coeff[0] * _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__delay_line_in;
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__out = _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__b_sum;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Product1
    _single_phase_inverter_current_controller_single_phase_pll1_product1__out = (_single_phase_inverter_current_controller_single_phase_pll1_sum2__out * _single_phase_inverter_current_controller_single_phase_pll1_integrator5__out);
    // Generated from the component: Single Phase Inverter.Current controller.Limit_PQref.limS_overPQ.S limiting over PQ
    _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Pref = _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__out;
    _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Qref = _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__out;
    _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Sref = _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__out;
    _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__S_PQref = sqrt(_single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Pref * _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Pref + _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Qref * _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Qref);
    if (_single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__S_PQref > _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Sref) {
        _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__P = (_single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Pref / _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__S_PQref) * _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Sref;
        _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Q = (_single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Qref / _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__S_PQref) * _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Sref;
    }
    else {
        _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__P = _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Pref;
        _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Q = _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Qref;
    }
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.Sum2
    _single_phase_inverter_current_controller_dq_current_controller_sum2__out =  - _single_phase_inverter_current_controller_alpha_beta_to_dq2__q + _single_phase_inverter_current_controller_current_ref1_product1__out;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.Sum1
    _single_phase_inverter_current_controller_dq_current_controller_sum1__out =  - _single_phase_inverter_current_controller_alpha_beta_to_dq2__d + _single_phase_inverter_current_controller_current_ref1_product2__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Abs1
    _single_phase_inverter_current_controller_single_phase_pll1_abs1__out = fabs(_single_phase_inverter_current_controller_single_phase_pll1_product8__out);
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d2.Gain1
    _single_phase_inverter_current_controller_dq_current_controller_pi_d2_gain1__out = 100.0 * _single_phase_inverter_current_controller_dq_current_controller_sum2__out;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d2.Gain2
    _single_phase_inverter_current_controller_dq_current_controller_pi_d2_gain2__out = 1000.0 * _single_phase_inverter_current_controller_dq_current_controller_sum2__out;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d.Gain1
    _single_phase_inverter_current_controller_dq_current_controller_pi_d_gain1__out = 100.0 * _single_phase_inverter_current_controller_dq_current_controller_sum1__out;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d.Gain2
    _single_phase_inverter_current_controller_dq_current_controller_pi_d_gain2__out = 1000.0 * _single_phase_inverter_current_controller_dq_current_controller_sum1__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Kd_LUT
    if(_single_phase_inverter_current_controller_single_phase_pll1_abs1__out <= _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_addrs[0]) {
        _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__fraction = (_single_phase_inverter_current_controller_single_phase_pll1_abs1__out - _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_addrs[0])
                / (_single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_addrs[1] - _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_addrs[0]);
        _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__leftIndex = 0;
    }
    else if(_single_phase_inverter_current_controller_single_phase_pll1_abs1__out < _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_addrs[99]) {
        _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__curAddr = 99 >> 1;
        _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__leftIndex = 0;
        _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__rightIndex = 99;
        while (1 < _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__rightIndex - _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__leftIndex) {
            if (_single_phase_inverter_current_controller_single_phase_pll1_abs1__out < _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_addrs[_single_phase_inverter_current_controller_single_phase_pll1_kd_lut__curAddr]) {
                _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__rightIndex = _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__curAddr;
            }
            else {
                _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__leftIndex = _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__curAddr;
            }
            _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__curAddr = (_single_phase_inverter_current_controller_single_phase_pll1_kd_lut__leftIndex + _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__rightIndex) >> 1;
        }
        _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__fraction = (_single_phase_inverter_current_controller_single_phase_pll1_abs1__out - _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_addrs[_single_phase_inverter_current_controller_single_phase_pll1_kd_lut__leftIndex])
                / (_single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_addrs[_single_phase_inverter_current_controller_single_phase_pll1_kd_lut__leftIndex + 1] - _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_addrs[_single_phase_inverter_current_controller_single_phase_pll1_kd_lut__leftIndex]);
    }
    else {
        _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__fraction = (_single_phase_inverter_current_controller_single_phase_pll1_abs1__out - _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_addrs[98])
                / (_single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_addrs[99] - _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_addrs[98]);
        _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__leftIndex = 98;
    }
    _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__value = (_single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_table[_single_phase_inverter_current_controller_single_phase_pll1_kd_lut__leftIndex + 1] - _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_table[_single_phase_inverter_current_controller_single_phase_pll1_kd_lut__leftIndex])
            * _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__fraction + _single_phase_inverter_current_controller_single_phase_pll1_kd_lut__lut_table[_single_phase_inverter_current_controller_single_phase_pll1_kd_lut__leftIndex];
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Ki_LUT
    if(_single_phase_inverter_current_controller_single_phase_pll1_abs1__out <= _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_addrs[0]) {
        _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__fraction = (_single_phase_inverter_current_controller_single_phase_pll1_abs1__out - _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_addrs[0])
                / (_single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_addrs[1] - _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_addrs[0]);
        _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__leftIndex = 0;
    }
    else if(_single_phase_inverter_current_controller_single_phase_pll1_abs1__out < _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_addrs[99]) {
        _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__curAddr = 99 >> 1;
        _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__leftIndex = 0;
        _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__rightIndex = 99;
        while (1 < _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__rightIndex - _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__leftIndex) {
            if (_single_phase_inverter_current_controller_single_phase_pll1_abs1__out < _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_addrs[_single_phase_inverter_current_controller_single_phase_pll1_ki_lut__curAddr]) {
                _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__rightIndex = _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__curAddr;
            }
            else {
                _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__leftIndex = _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__curAddr;
            }
            _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__curAddr = (_single_phase_inverter_current_controller_single_phase_pll1_ki_lut__leftIndex + _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__rightIndex) >> 1;
        }
        _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__fraction = (_single_phase_inverter_current_controller_single_phase_pll1_abs1__out - _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_addrs[_single_phase_inverter_current_controller_single_phase_pll1_ki_lut__leftIndex])
                / (_single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_addrs[_single_phase_inverter_current_controller_single_phase_pll1_ki_lut__leftIndex + 1] - _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_addrs[_single_phase_inverter_current_controller_single_phase_pll1_ki_lut__leftIndex]);
    }
    else {
        _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__fraction = (_single_phase_inverter_current_controller_single_phase_pll1_abs1__out - _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_addrs[98])
                / (_single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_addrs[99] - _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_addrs[98]);
        _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__leftIndex = 98;
    }
    _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__value = (_single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_table[_single_phase_inverter_current_controller_single_phase_pll1_ki_lut__leftIndex + 1] - _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_table[_single_phase_inverter_current_controller_single_phase_pll1_ki_lut__leftIndex])
            * _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__fraction + _single_phase_inverter_current_controller_single_phase_pll1_ki_lut__lut_table[_single_phase_inverter_current_controller_single_phase_pll1_ki_lut__leftIndex];
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Kp_LUT
    if(_single_phase_inverter_current_controller_single_phase_pll1_abs1__out <= _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_addrs[0]) {
        _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__fraction = (_single_phase_inverter_current_controller_single_phase_pll1_abs1__out - _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_addrs[0])
                / (_single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_addrs[1] - _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_addrs[0]);
        _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__leftIndex = 0;
    }
    else if(_single_phase_inverter_current_controller_single_phase_pll1_abs1__out < _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_addrs[99]) {
        _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__curAddr = 99 >> 1;
        _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__leftIndex = 0;
        _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__rightIndex = 99;
        while (1 < _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__rightIndex - _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__leftIndex) {
            if (_single_phase_inverter_current_controller_single_phase_pll1_abs1__out < _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_addrs[_single_phase_inverter_current_controller_single_phase_pll1_kp_lut__curAddr]) {
                _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__rightIndex = _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__curAddr;
            }
            else {
                _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__leftIndex = _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__curAddr;
            }
            _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__curAddr = (_single_phase_inverter_current_controller_single_phase_pll1_kp_lut__leftIndex + _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__rightIndex) >> 1;
        }
        _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__fraction = (_single_phase_inverter_current_controller_single_phase_pll1_abs1__out - _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_addrs[_single_phase_inverter_current_controller_single_phase_pll1_kp_lut__leftIndex])
                / (_single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_addrs[_single_phase_inverter_current_controller_single_phase_pll1_kp_lut__leftIndex + 1] - _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_addrs[_single_phase_inverter_current_controller_single_phase_pll1_kp_lut__leftIndex]);
    }
    else {
        _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__fraction = (_single_phase_inverter_current_controller_single_phase_pll1_abs1__out - _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_addrs[98])
                / (_single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_addrs[99] - _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_addrs[98]);
        _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__leftIndex = 98;
    }
    _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__value = (_single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_table[_single_phase_inverter_current_controller_single_phase_pll1_kp_lut__leftIndex + 1] - _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_table[_single_phase_inverter_current_controller_single_phase_pll1_kp_lut__leftIndex])
            * _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__fraction + _single_phase_inverter_current_controller_single_phase_pll1_kp_lut__lut_table[_single_phase_inverter_current_controller_single_phase_pll1_kp_lut__leftIndex];
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d2.Sum5
    _single_phase_inverter_current_controller_dq_current_controller_pi_d2_sum5__out = _single_phase_inverter_current_controller_dq_current_controller_pi_d2_gain1__out + _single_phase_inverter_current_controller_dq_current_controller_pi_d2_integrator1__out;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d.Sum5
    _single_phase_inverter_current_controller_dq_current_controller_pi_d_sum5__out = _single_phase_inverter_current_controller_dq_current_controller_pi_d_gain1__out + _single_phase_inverter_current_controller_dq_current_controller_pi_d_integrator1__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Product6
    _single_phase_inverter_current_controller_single_phase_pll1_product6__out = (_single_phase_inverter_current_controller_single_phase_pll1_kd_lut__value * _single_phase_inverter_current_controller_single_phase_pll1_product8__out);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Product5
    _single_phase_inverter_current_controller_single_phase_pll1_product5__out = (_single_phase_inverter_current_controller_single_phase_pll1_ki_lut__value * _single_phase_inverter_current_controller_single_phase_pll1_product8__out);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Product7
    _single_phase_inverter_current_controller_single_phase_pll1_product7__out = (_single_phase_inverter_current_controller_single_phase_pll1_kp_lut__value * _single_phase_inverter_current_controller_single_phase_pll1_product8__out);
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d2.Limit1
    _single_phase_inverter_current_controller_dq_current_controller_pi_d2_limit1__out = MIN(MAX(_single_phase_inverter_current_controller_dq_current_controller_pi_d2_sum5__out, -500.0), 500.0);
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d.Limit1
    _single_phase_inverter_current_controller_dq_current_controller_pi_d_limit1__out = MIN(MAX(_single_phase_inverter_current_controller_dq_current_controller_pi_d_sum5__out, -500.0), 500.0);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Discrete Transfer Function1
    X_UnInt32 _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__i;
    _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__a_sum = 0.0f;
    _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__b_sum = 0.0f;
    _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__delay_line_in = 0.0f;
    for (_single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__i = 0; _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__i < 1; _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__i++) {
        _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__b_sum += _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__b_coeff[_single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__i + 1] * _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__states[_single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__i];
    }
    _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__a_sum += _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__states[0] * _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__a_coeff[1];
    _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__delay_line_in = _single_phase_inverter_current_controller_single_phase_pll1_product6__out - _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__a_sum;
    _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__b_sum += _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__b_coeff[0] * _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__delay_line_in;
    _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__out = _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__b_sum;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d2.Sum6
    _single_phase_inverter_current_controller_dq_current_controller_pi_d2_sum6__out =  - _single_phase_inverter_current_controller_dq_current_controller_pi_d2_sum5__out + _single_phase_inverter_current_controller_dq_current_controller_pi_d2_limit1__out;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.Sum12
    _single_phase_inverter_current_controller_dq_current_controller_sum12__out = _single_phase_inverter_current_controller_dq_current_controller_sum13__out + _single_phase_inverter_current_controller_dq_current_controller_pi_d2_limit1__out;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d.Sum6
    _single_phase_inverter_current_controller_dq_current_controller_pi_d_sum6__out =  - _single_phase_inverter_current_controller_dq_current_controller_pi_d_sum5__out + _single_phase_inverter_current_controller_dq_current_controller_pi_d_limit1__out;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.Sum9
    _single_phase_inverter_current_controller_dq_current_controller_sum9__out = _single_phase_inverter_current_controller_dq_current_controller_pi_d_limit1__out + _single_phase_inverter_current_controller_dq_current_controller_sum10__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Sum8
    _single_phase_inverter_current_controller_single_phase_pll1_sum8__out = _single_phase_inverter_current_controller_single_phase_pll1_product7__out + _single_phase_inverter_current_controller_single_phase_pll1_i__out + _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__out;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d2.Kb
    _single_phase_inverter_current_controller_dq_current_controller_pi_d2_kb__out = 1.0 * _single_phase_inverter_current_controller_dq_current_controller_pi_d2_sum6__out;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.Product7
    _single_phase_inverter_current_controller_dq_current_controller_product7__out = (_single_phase_inverter_current_controller_dq_current_controller_sum12__out) * 1.0 / (_single_phase_inverter_current_controller_dq_current_controller_limit3__out);
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d.Kb
    _single_phase_inverter_current_controller_dq_current_controller_pi_d_kb__out = 1.0 * _single_phase_inverter_current_controller_dq_current_controller_pi_d_sum6__out;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.Product5
    _single_phase_inverter_current_controller_dq_current_controller_product5__out = (_single_phase_inverter_current_controller_dq_current_controller_sum9__out) * 1.0 / (_single_phase_inverter_current_controller_dq_current_controller_limit3__out);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Limit2
    _single_phase_inverter_current_controller_single_phase_pll1_limit2__out = MIN(MAX(_single_phase_inverter_current_controller_single_phase_pll1_sum8__out, -62.83185307179586), 62.83185307179586);
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d2.Sum7
    _single_phase_inverter_current_controller_dq_current_controller_pi_d2_sum7__out = _single_phase_inverter_current_controller_dq_current_controller_pi_d2_gain2__out + _single_phase_inverter_current_controller_dq_current_controller_pi_d2_kb__out;
    // Generated from the component: Single Phase Inverter.Current controller.Limit4
    _single_phase_inverter_current_controller_limit4__out = MIN(MAX(_single_phase_inverter_current_controller_dq_current_controller_product7__out, -1.0), 1.0);
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d.Sum7
    _single_phase_inverter_current_controller_dq_current_controller_pi_d_sum7__out = _single_phase_inverter_current_controller_dq_current_controller_pi_d_gain2__out + _single_phase_inverter_current_controller_dq_current_controller_pi_d_kb__out;
    // Generated from the component: Single Phase Inverter.Current controller.Limit3
    _single_phase_inverter_current_controller_limit3__out = MIN(MAX(_single_phase_inverter_current_controller_dq_current_controller_product5__out, -1.0), 1.0);
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Sum5
    _single_phase_inverter_current_controller_single_phase_pll1_sum5__out = _single_phase_inverter_current_controller_single_phase_pll1_limit2__out + _single_phase_inverter_current_controller_single_phase_pll1_const__out;
    // Generated from the component: Single Phase Inverter.Current controller.dq to alpha beta1
    _single_phase_inverter_current_controller_dq_to_alpha_beta1__k1 = cos(_single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__out);
    _single_phase_inverter_current_controller_dq_to_alpha_beta1__k2 = sin(_single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__out);
    _single_phase_inverter_current_controller_dq_to_alpha_beta1__alpha = _single_phase_inverter_current_controller_dq_to_alpha_beta1__k2 * _single_phase_inverter_current_controller_limit3__out + _single_phase_inverter_current_controller_dq_to_alpha_beta1__k1 * _single_phase_inverter_current_controller_limit4__out;
    _single_phase_inverter_current_controller_dq_to_alpha_beta1__beta = _single_phase_inverter_current_controller_dq_to_alpha_beta1__k2 * _single_phase_inverter_current_controller_limit4__out - _single_phase_inverter_current_controller_dq_to_alpha_beta1__k1 * _single_phase_inverter_current_controller_limit3__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Sum10
    _single_phase_inverter_current_controller_single_phase_pll1_sum10__out = _single_phase_inverter_current_controller_single_phase_pll1_sum5__out - _single_phase_inverter_current_controller_single_phase_pll1_integrator6__out;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.integrator_with_reset
    _single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__in = _single_phase_inverter_current_controller_single_phase_pll1_sum5__out;
    _single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__out = _single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__out_calc;
    // Generated from the component: Single Phase Inverter.Gain1
    _single_phase_inverter_gain1__out = -1.0 * _single_phase_inverter_current_controller_dq_to_alpha_beta1__alpha;
    // Generated from the component: Single Phase Inverter.Termination1
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Gain6
    _single_phase_inverter_current_controller_single_phase_pll1_gain6__out = 628.3185307179587 * _single_phase_inverter_current_controller_single_phase_pll1_sum10__out;
    // Generated from the component: Single Phase Inverter.Single Phase Inverter.PWM_Modulator
    _single_phase_inverter_single_phase_inverter_pwm_modulator__limited_in[0] = MIN(MAX(_single_phase_inverter_current_controller_dq_to_alpha_beta1__alpha, -1.0), 1.0);
    HIL_OutInt32(0x2000040 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[0], ((unsigned)((_single_phase_inverter_single_phase_inverter_pwm_modulator__limited_in[0] - (-1.0)) * 2000.0)));
    _single_phase_inverter_single_phase_inverter_pwm_modulator__limited_in[1] = MIN(MAX(_single_phase_inverter_gain1__out, -1.0), 1.0);
    HIL_OutInt32(0x2000040 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[1], ((unsigned)((_single_phase_inverter_single_phase_inverter_pwm_modulator__limited_in[1] - (-1.0)) * 2000.0)));
    if (_single_phase_inverter_logical_operator2__out == 0x0) {
        // pwm_modulator_en
        HIL_OutInt32(0x2000000 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[0], 0x0);
        HIL_OutInt32(0x2000000 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[1], 0x0);
    }
    else {
        // pwm_modulator_en
        HIL_OutInt32(0x2000000 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[0], 0x1);
        HIL_OutInt32(0x2000000 + _single_phase_inverter_single_phase_inverter_pwm_modulator__channels[1], 0x1);
    }
    HIL_OutInt32(0x2000140, _single_phase_inverter_single_phase_inverter_pwm_modulator__update_mask);
    //@cmp.out.block.end
    //////////////////////////////////////////////////////////////////////////
    // Update block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.update.block.start
    // Generated from the component: Single Phase Inverter.Current controller.Limit_PQref.Unit Delay1
    _single_phase_inverter_current_controller_limit_pqref_unit_delay1__state = _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__P;
    // Generated from the component: Single Phase Inverter.Current controller.Limit_PQref.Unit Delay2
    _single_phase_inverter_current_controller_limit_pqref_unit_delay2__state = _single_phase_inverter_current_controller_limit_pqref_lims_overpq_s_limiting_over_pq__Q;
    // Generated from the component: Single Phase Inverter.Current controller.Power_Meas.Power_Meas_DQpu.S_and_pf
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.I
    if (!_single_phase_inverter_current_controller_single_phase_pll1_i__av_active || ((_single_phase_inverter_current_controller_single_phase_pll1_i__av_active < 0 && _single_phase_inverter_current_controller_single_phase_pll1_product5__out > 0 ) || (_single_phase_inverter_current_controller_single_phase_pll1_i__av_active > 0 && _single_phase_inverter_current_controller_single_phase_pll1_product5__out < 0 ))) {
        _single_phase_inverter_current_controller_single_phase_pll1_i__integrator_state += 1.0 * _single_phase_inverter_current_controller_single_phase_pll1_product5__out * 0.0001;
    }
    else {
        _single_phase_inverter_current_controller_single_phase_pll1_i__integrator_state = _single_phase_inverter_current_controller_single_phase_pll1_i__out;
    }
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator1
    _single_phase_inverter_current_controller_single_phase_pll1_integrator1__state += _single_phase_inverter_current_controller_single_phase_pll1_product1__out * 0.0001;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator10
    _single_phase_inverter_current_controller_single_phase_pll1_integrator10__state += _single_phase_inverter_current_controller_single_phase_pll1_gain11__out * 0.0001;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator2
    _single_phase_inverter_current_controller_single_phase_pll1_integrator2__state += _single_phase_inverter_current_controller_single_phase_pll1_product2__out * 0.0001;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator3
    _single_phase_inverter_current_controller_single_phase_pll1_integrator3__state += _single_phase_inverter_current_controller_single_phase_pll1_gain4__out * 0.0001;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator4
    _single_phase_inverter_current_controller_single_phase_pll1_integrator4__state += _single_phase_inverter_current_controller_single_phase_pll1_gain5__out * 0.0001;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator5
    _single_phase_inverter_current_controller_single_phase_pll1_integrator5__state += _single_phase_inverter_current_controller_single_phase_pll1_gain7__out * 0.0001;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator6
    _single_phase_inverter_current_controller_single_phase_pll1_integrator6__state += _single_phase_inverter_current_controller_single_phase_pll1_gain6__out * 0.0001;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator7
    _single_phase_inverter_current_controller_single_phase_pll1_integrator7__state += _single_phase_inverter_current_controller_single_phase_pll1_gain9__out * 0.0001;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator8
    _single_phase_inverter_current_controller_single_phase_pll1_integrator8__state += _single_phase_inverter_current_controller_single_phase_pll1_gain8__out * 0.0001;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Integrator9
    _single_phase_inverter_current_controller_single_phase_pll1_integrator9__state += _single_phase_inverter_current_controller_single_phase_pll1_gain10__out * 0.0001;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.C function1
    // Generated from the component: Single Phase Inverter.RMS value2
    if( _single_phase_inverter_rms_value2__zc ) {
        if (_single_phase_inverter_iout_ia1__out != _single_phase_inverter_rms_value2__previous_value)
            _single_phase_inverter_rms_value2__correction = - _single_phase_inverter_rms_value2__previous_value / (_single_phase_inverter_iout_ia1__out - _single_phase_inverter_rms_value2__previous_value);
        if (_single_phase_inverter_rms_value2__correction < 0)
            _single_phase_inverter_rms_value2__correction = 0;
        else
            _single_phase_inverter_rms_value2__correction = 0;
        _single_phase_inverter_rms_value2__sample_cnt += _single_phase_inverter_rms_value2__correction - _single_phase_inverter_rms_value2__previous_correction;
        _single_phase_inverter_rms_value2__out_state = sqrt(_single_phase_inverter_rms_value2__square_sum / _single_phase_inverter_rms_value2__sample_cnt);
        _single_phase_inverter_rms_value2__sample_cnt = 0;
        _single_phase_inverter_rms_value2__previous_correction = _single_phase_inverter_rms_value2__correction;
        _single_phase_inverter_rms_value2__square_sum = 0;
    } else if ( _single_phase_inverter_rms_value2__sample_cnt >= 5000 ) {
        _single_phase_inverter_rms_value2__out_state = sqrt(_single_phase_inverter_rms_value2__square_sum / _single_phase_inverter_rms_value2__sample_cnt);
        _single_phase_inverter_rms_value2__sample_cnt = 0;
        _single_phase_inverter_rms_value2__square_sum = 0;
    }
    _single_phase_inverter_rms_value2__previous_value = _single_phase_inverter_iout_ia1__out;
    _single_phase_inverter_rms_value2__square_sum += _single_phase_inverter_iout_ia1__out * _single_phase_inverter_iout_ia1__out;
    _single_phase_inverter_rms_value2__sample_cnt ++;
    // Generated from the component: Single Phase Inverter.RMS value1
    if( _single_phase_inverter_rms_value1__zc ) {
        if (_single_phase_inverter_vout_va1__out != _single_phase_inverter_rms_value1__previous_value)
            _single_phase_inverter_rms_value1__correction = - _single_phase_inverter_rms_value1__previous_value / (_single_phase_inverter_vout_va1__out - _single_phase_inverter_rms_value1__previous_value);
        if (_single_phase_inverter_rms_value1__correction < 0)
            _single_phase_inverter_rms_value1__correction = 0;
        else
            _single_phase_inverter_rms_value1__correction = 0;
        _single_phase_inverter_rms_value1__sample_cnt += _single_phase_inverter_rms_value1__correction - _single_phase_inverter_rms_value1__previous_correction;
        _single_phase_inverter_rms_value1__out_state = sqrt(_single_phase_inverter_rms_value1__square_sum / _single_phase_inverter_rms_value1__sample_cnt);
        _single_phase_inverter_rms_value1__sample_cnt = 0;
        _single_phase_inverter_rms_value1__previous_correction = _single_phase_inverter_rms_value1__correction;
        _single_phase_inverter_rms_value1__square_sum = 0;
    } else if ( _single_phase_inverter_rms_value1__sample_cnt >= 5000 ) {
        _single_phase_inverter_rms_value1__out_state = sqrt(_single_phase_inverter_rms_value1__square_sum / _single_phase_inverter_rms_value1__sample_cnt);
        _single_phase_inverter_rms_value1__sample_cnt = 0;
        _single_phase_inverter_rms_value1__square_sum = 0;
    }
    _single_phase_inverter_rms_value1__previous_value = _single_phase_inverter_vout_va1__out;
    _single_phase_inverter_rms_value1__square_sum += _single_phase_inverter_vout_va1__out * _single_phase_inverter_vout_va1__out;
    _single_phase_inverter_rms_value1__sample_cnt ++;
    // Generated from the component: Single Phase Inverter.Current controller.OSG.Discrete Transfer Function1
    _single_phase_inverter_current_controller_osg_discrete_transfer_function1__states[0] = _single_phase_inverter_current_controller_osg_discrete_transfer_function1__delay_line_in;
    // Generated from the component: Single Phase Inverter.delay1
    // Generated from the component: Single Phase Inverter.Current controller.Limit_PQref.priority_PQlim.PQ limiting with priority
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d.Integrator1
    _single_phase_inverter_current_controller_dq_current_controller_pi_d_integrator1__state += _single_phase_inverter_current_controller_dq_current_controller_pi_d_sum7__out * 0.0001;
    if (_single_phase_inverter_logical_operator2__out > 0)
        _single_phase_inverter_current_controller_dq_current_controller_pi_d_integrator1__reset_state = 1;
    else if (_single_phase_inverter_logical_operator2__out < 0)
        _single_phase_inverter_current_controller_dq_current_controller_pi_d_integrator1__reset_state = -1;
    else
        _single_phase_inverter_current_controller_dq_current_controller_pi_d_integrator1__reset_state = 0;
    // Generated from the component: Single Phase Inverter.Current controller.Dq current controller.PI_d2.Integrator1
    _single_phase_inverter_current_controller_dq_current_controller_pi_d2_integrator1__state += _single_phase_inverter_current_controller_dq_current_controller_pi_d2_sum7__out * 0.0001;
    if (_single_phase_inverter_logical_operator2__out > 0)
        _single_phase_inverter_current_controller_dq_current_controller_pi_d2_integrator1__reset_state = 1;
    else if (_single_phase_inverter_logical_operator2__out < 0)
        _single_phase_inverter_current_controller_dq_current_controller_pi_d2_integrator1__reset_state = -1;
    else
        _single_phase_inverter_current_controller_dq_current_controller_pi_d2_integrator1__reset_state = 0;
    // Generated from the component: Single Phase Inverter.Current controller.Limit_PQref.P rate limit
    if (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__P - _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__state > 0.0005)
        _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__state += (0.0005);
    else  if (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__P - _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__state < -0.0005)
        _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__state += (-0.0005);
    else
        _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__state = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__P;
    _single_phase_inverter_current_controller_limit_pqref_p_rate_limit__first_step = 0;
    // Generated from the component: Single Phase Inverter.Current controller.Limit_PQref.Q rate limit
    if (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q - _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__state > 0.0005)
        _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__state += (0.0005);
    else  if (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q - _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__state < -0.0005)
        _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__state += (-0.0005);
    else
        _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__state = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__Q;
    _single_phase_inverter_current_controller_limit_pqref_q_rate_limit__first_step = 0;
    // Generated from the component: Single Phase Inverter.Current controller.Limit_PQref.S rate limit
    if (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__S - _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__state > 0.0005)
        _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__state += (0.0005);
    else  if (_single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__S - _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__state < -0.0005)
        _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__state += (-0.0005);
    else
        _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__state = _single_phase_inverter_current_controller_limit_pqref_priority_pqlim_pq_limiting_with_priority__S;
    _single_phase_inverter_current_controller_limit_pqref_s_rate_limit__first_step = 0;
    // Generated from the component: Single Phase Inverter.Current controller.Power_Meas.Power_Meas_DQpu.LPF_P
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__states[0] = _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_p__delay_line_in;
    // Generated from the component: Single Phase Inverter.Current controller.Power_Meas.Power_Meas_DQpu.LPF_Q
    _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__states[0] = _single_phase_inverter_current_controller_power_meas_power_meas_dqpu_lpf_q__delay_line_in;
    // Generated from the component: Single Phase Inverter.Current controller.Limit_PQref.limS_overPQ.S limiting over PQ
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.Discrete Transfer Function1
    _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__states[0] = _single_phase_inverter_current_controller_single_phase_pll1_discrete_transfer_function1__delay_line_in;
    // Generated from the component: Single Phase Inverter.Current controller.Single phase PLL1.integrator_with_reset
    _single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__out_calc += _single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__in * 0.0001;
    if (_single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__out_calc > _single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__reset_value)_single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__out_calc -= _single_phase_inverter_current_controller_single_phase_pll1_integrator_with_reset__reset_value;
    //@cmp.update.block.end
}
void TimerCounterHandler_1_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rTimerCounterHandler_1");
#endif
    //////////////////////////////////////////////////////////////////////////
    // Set tunable parameters
    //////////////////////////////////////////////////////////////////////////
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.DC Voltage Controller.DC Energy Calculation1.Constant1
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.DC Voltage Controller.DC Energy Calculation2.Constant1
    //////////////////////////////////////////////////////////////////////////
    // Output block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.out.block.start
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.DC Voltage Controller.DC Energy Calculation1.Constant1
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.DC Voltage Controller.DC Energy Calculation2.Constant1
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.MPPT.Rate Transition5.Input
    _single_phase_inverter_vdc_mppt_mppt_rate_transition5_output__out = _single_phase_inverter_rate_transition2_output__out;
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.DC Voltage Controller.DC Energy Calculation2.power of 2
    _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation2_power_of_2__out = pow(_single_phase_inverter_rate_transition2_output__out, _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation2_constant1__out);
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.DC Voltage Controller.DC Energy Calculation1.power of 2
    _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation1_power_of_2__out = pow(_single_phase_inverter_vdc_mppt_mppt_rate_transition2_output__out, _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation1_constant1__out);
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.DC Voltage Controller.Probe Vdc ref
    HIL_OutAO(0x2015, (float)_single_phase_inverter_vdc_mppt_mppt_rate_transition2_output__out);
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.Vdc_ref
    HIL_OutAO(0x2018, (float)_single_phase_inverter_vdc_mppt_mppt_rate_transition2_output__out);
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.DC Voltage Controller.DC Energy Calculation2.Gain2
    _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation2_gain2__out = 0.5 * _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation2_power_of_2__out;
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.DC Voltage Controller.DC Energy Calculation1.Gain2
    _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation1_gain2__out = 0.5 * _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation1_power_of_2__out;
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.DC Voltage Controller.DC Energy Calculation2.Gain3
    _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation2_gain3__out = 0.188 * _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation2_gain2__out;
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.DC Voltage Controller.DC Energy Calculation1.Gain3
    _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation1_gain3__out = 0.188 * _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation1_gain2__out;
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.DC Voltage Controller.Sum1
    _single_phase_inverter_vdc_mppt_dc_voltage_controller_sum1__out = _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation1_gain3__out - _single_phase_inverter_vdc_mppt_dc_voltage_controller_dc_energy_calculation2_gain3__out;
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.DC Voltage Controller.PI with Antiwindup.C function1
    _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__enable = _single_phase_inverter_rate_transition3_output__out;
    _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__error = _single_phase_inverter_vdc_mppt_dc_voltage_controller_sum1__out;
    if (_single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__enable == 0) {
        _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__sum = 0;
        _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__error = 0;
    }
    _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__enable_old = _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__enable;
    _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__out = (-0.01) * _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__sum + (-8.0) * _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__error;
    if ((-0.01) != 0)_single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__sum = _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__sum + _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__error;
    if (_single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__out > 40000.0) {
        _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__out = 40000.0;
        if ((-0.01) != 0)_single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__sum = (_single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__out - ((-8.0) * _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__error)) / (-0.01);
    }
    if (_single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__out < (-40000.0)) {
        _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__out = (-40000.0);
        if ((-0.01) != 0)_single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__sum = (_single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__out - ((-8.0) * _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__error)) / (-0.01);
    }
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.DC Voltage Controller.Probe Vdc ref1
    HIL_OutAO(0x2016, (float)_single_phase_inverter_vdc_mppt_dc_voltage_controller_sum1__out);
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.Preff
    HIL_OutAO(0x2017, (float)_single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__out);
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.Rate Transition1.Input
    _single_phase_inverter_vdc_mppt_rate_transition1_output__out = _single_phase_inverter_vdc_mppt_dc_voltage_controller_pi_with_antiwindup_c_function1__out;
    //@cmp.out.block.end
    //////////////////////////////////////////////////////////////////////////
    // Update block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.update.block.start
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.DC Voltage Controller.PI with Antiwindup.C function1
    //@cmp.update.block.end
}
void TimerCounterHandler_2_user_sp_cpu0_dev0() {
#if DEBUG_MODE
    printf("\n\rTimerCounterHandler_2");
#endif
    //////////////////////////////////////////////////////////////////////////
    // Set tunable parameters
    //////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////
    // Output block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.out.block.start
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.MPPT.MPPT_mode
    _single_phase_inverter_vdc_mppt_mppt_mppt_mode__out = XIo_InFloat(0x55000130);
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.MPPT.V_incr
    _single_phase_inverter_vdc_mppt_mppt_v_incr__out = XIo_InFloat(0x55000134);
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.MPPT.MPPT
    _single_phase_inverter_vdc_mppt_mppt_mppt__V_k = _single_phase_inverter_vdc_mppt_mppt_rate_transition5_output__out;
    _single_phase_inverter_vdc_mppt_mppt_mppt__enable = _single_phase_inverter_vdc_mppt_mppt_mppt_mode__out;
    _single_phase_inverter_vdc_mppt_mppt_mppt__incr = _single_phase_inverter_vdc_mppt_mppt_v_incr__out;
    if (_single_phase_inverter_vdc_mppt_mppt_mppt__enable == 1) {
        _single_phase_inverter_vdc_mppt_mppt_mppt__V_ref = 400;
    }
    else if (_single_phase_inverter_vdc_mppt_mppt_mppt__enable == 2) {
        _single_phase_inverter_vdc_mppt_mppt_mppt__V_ref = 400;
    }
    else if (_single_phase_inverter_vdc_mppt_mppt_mppt__enable == 3) {
        _single_phase_inverter_vdc_mppt_mppt_mppt__V_ref = 400;
    }
    else {
        _single_phase_inverter_vdc_mppt_mppt_mppt__V_ref = 400;
    }
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.MPPT.Rate Transition2.Input
    _single_phase_inverter_vdc_mppt_mppt_rate_transition2_output__out = _single_phase_inverter_vdc_mppt_mppt_mppt__V_ref;
    //@cmp.out.block.end
    //////////////////////////////////////////////////////////////////////////
    // Update block
    //////////////////////////////////////////////////////////////////////////
    //@cmp.update.block.start
    // Generated from the component: Single Phase Inverter.Vdc_MPPT.MPPT.MPPT
    //@cmp.update.block.end
}
// ----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------